package cf.awidiyadew.drawerexpandablelistview.data;

/**
 * Created by awidiyadew on 12/09/16.
 */
public class BaseItem {
    private String mName;

    public BaseItem(String name) {
        mName = name;
    }

    public String getName() {
        return mName;
    }
}
