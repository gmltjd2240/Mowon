package cf.awidiyadew.drawerexpandablelistview.dto;

public class StaticVariable {

    public static String academy_name = "";
    public static String class_name = "";
    public static String userName = "";
    public static String userGender = "";
    public static String userTel = "";
    public static String userPw = "";
    public static String userBirth = "";
    public static String userMAC = "";
    public static String guardianName = "";
    public static String guardianTel = "";
    public static String loginType = "";

    public static void staticVariableLogout(){
        academy_name = "";
        class_name = "";
        userName = "";
        userGender = "";
        userTel = "";
        userPw = "";
        userBirth = "";
        userMAC = "";
        guardianName = "";
        guardianTel = "";
        loginType = "";
    }

}
