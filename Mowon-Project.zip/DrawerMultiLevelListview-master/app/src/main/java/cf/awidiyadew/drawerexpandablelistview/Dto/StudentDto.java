package cf.awidiyadew.drawerexpandablelistview.dto;

public class StudentDto {
    String ACADEMY_NAME;
    String CLASS_NAME;
    String USER_NAME;
    String USER_GENDER;
    String USER_TEL;
    String USER_PW;
    String USER_BIRTH;
    String USER_MAC;
    String GUARDIAN_NAME;
    String GUARDIAN_TEL;
    String LOGIN_TYPE;


    public String getACADEMY_NAME() {
        return ACADEMY_NAME;
    }

    public void setACADEMY_NAME(String ACADEMY_NAME) {
        this.ACADEMY_NAME = ACADEMY_NAME;
    }

    public String getCLASS_NAME() {
        return CLASS_NAME;
    }

    public void setCLASS_NAME(String CLASS_NAME) {
        this.CLASS_NAME = CLASS_NAME;
    }

    public String getUSER_NAME() {
        return USER_NAME;
    }

    public void setUSER_NAME(String USER_NAME) {
        this.USER_NAME = USER_NAME;
    }

    public String getUSER_GENDER() {
        return USER_GENDER;
    }

    public void setUSER_GENDER(String USER_GENDER) {
        this.USER_GENDER = USER_GENDER;
    }

    public String getUSER_TEL() {
        return USER_TEL;
    }

    public void setUSER_TEL(String USER_TEL) {
        this.USER_TEL = USER_TEL;
    }

    public String getUSER_PW() {
        return USER_PW;
    }

    public void setUSER_PW(String USER_PW) {
        this.USER_PW = USER_PW;
    }

    public String getUSER_BIRTH() {
        return USER_BIRTH;
    }

    public void setUSER_BIRTH(String USER_BIRTH) {
        this.USER_BIRTH = USER_BIRTH;
    }

    public String getUSER_MAC() {
        return USER_MAC;
    }

    public void setUSER_MAC(String USER_MAC) {
        this.USER_MAC = USER_MAC;
    }

    public String getGUARDIAN_NAME() {
        return GUARDIAN_NAME;
    }

    public void setGUARDIAN_NAME(String GUARDIAN_NAME) {
        this.GUARDIAN_NAME = GUARDIAN_NAME;
    }

    public String getGUARDIAN_TEL() {
        return GUARDIAN_TEL;
    }

    public void setGUARDIAN_TEL(String GUARDIAN_TEL) {
        this.GUARDIAN_TEL = GUARDIAN_TEL;
    }

    public String getLOGIN_TYPE() {
        return LOGIN_TYPE;
    }

    public void setLOGIN_TYPE(String LOGIN_TYPE) {
        this.LOGIN_TYPE = LOGIN_TYPE;
    }
}
