package cf.awidiyadew.drawerexpandablelistview.task;

public class TaskServer {
    public static final String ip = "192.168.0.112";
}
