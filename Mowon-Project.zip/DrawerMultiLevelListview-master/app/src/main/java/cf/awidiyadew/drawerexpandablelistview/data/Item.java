package cf.awidiyadew.drawerexpandablelistview.data;

/**
 * Created by awidiyadew on 12/09/16.
 */
public class Item extends BaseItem {
    public Item(String name) {
        super(name);
    }
}
