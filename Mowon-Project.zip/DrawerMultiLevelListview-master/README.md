# DrawerMultiLevelListview
Example android navigation drawer with multi level (unlimit) expandable list view.
Implement multi level list view library from https://github.com/open-rnd/android-multi-level-listview

<br>

## Screenshot
<img src="https://github.com/awidiyadew/DrawerMultiLevelListview/blob/master/screenshot/1.png" height="450px" title="list level 1"/>
<img src="https://github.com/awidiyadew/DrawerMultiLevelListview/blob/master/screenshot/2.png" height="450px" title="list level 2"/>
<img src="https://github.com/awidiyadew/DrawerMultiLevelListview/blob/master/screenshot/3.png" height="450px" title="list level 3"/>

