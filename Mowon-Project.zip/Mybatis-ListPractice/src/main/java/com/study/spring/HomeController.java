package com.study.spring;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.study.spring.dao.IDao;
import com.study.spring.dto.BPageInfo;
import com.study.spring.dto.ContentDto;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
//	ContentDao dao;
//	
//	@Autowired
//	public void setDao(ContentDao dao) {
//		this.dao = dao;
//	}
	
	int listCount = 10;	// 한 페이지당 보여줄 게시물의 갯수
	int pageCount = 10;	// 하단에 보여줄 페이지 리스트의 갯수
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	
	public BPageInfo page(HttpServletRequest request, Model model) {
		
		HttpSession session = null;
		session = request.getSession();
		
		IDao dao = sqlSession.getMapper(IDao.class);
		
		int curPage = 1;
		
		
		try {
			String sPage = request.getParameter("page");
			curPage = Integer.parseInt(sPage);
			
			if (session.getAttribute("cpage") != null) {
				curPage = (Integer) session.getAttribute("cpage");
			}
		} catch (Exception e) {
		}
	
		int totalCount = dao.pageDao().intValue();

		
		// 총 페이지 수
		int totalPage = totalCount / listCount;
		if (totalCount % listCount > 0)
			totalPage++;
		
		// 현재 페이지
		int myCurPage = curPage;
		if (myCurPage > totalPage)
			myCurPage = totalPage;
		if (myCurPage < 1)
			myCurPage = 1;
		
		// 시작 페이지-
		int startPage = ((myCurPage - 1) / pageCount) * pageCount +1;
		
		// 끝 페이지
		int endPage = startPage + pageCount -1;
		
		if (endPage > totalPage) {
			endPage = totalPage;
		}
		
		
		
		BPageInfo pinfo = new BPageInfo();
		pinfo.setTotalCount(totalCount);
		pinfo.setListCount(listCount);
		pinfo.setTotalPage(totalPage);
		pinfo.setCurPage(myCurPage);
		pinfo.setPageCount(pageCount);
		pinfo.setStartPage(startPage);
		pinfo.setEndPage(endPage);
	
		return pinfo;
	}
		
	
	
	@RequestMapping("/list")
	public String list(HttpServletRequest request, Model model) {
//		ArrayList<ContentDto> dtos = dao.listDao();
//		model.addAttribute("list", dtos);
		
		IDao dao = sqlSession.getMapper(IDao.class);
		
		BPageInfo page = page(request, model);
		model.addAttribute("page", page);
		
		int curPage = page.getCurPage();
		
		int nStart = (curPage - 1) * listCount + 1;
		int nEnd = (curPage - 1) * listCount + listCount;
		
		model.addAttribute("list", dao.listDao(nEnd, nStart));
		
		return "list";
	}
	
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request, Model model) {
		IDao dao = sqlSession.getMapper(IDao.class);
		String bId = request.getParameter("bId");
		
		dao.upHit(bId);
		ContentDto content = dao.contentDao(bId);
		model.addAttribute("content_view", content);
		
		return "content_view";
	}
	
	@RequestMapping("/write_view")
	public String write_view() {
		
		return "/write_view";
	}
	
//	@RequestMapping("/write")
//	public String write(HttpServletRequest request, Model model) {
//		IDao dao = sqlSession.getMapper(IDao.class);
//		dao.writeDao(request.getParameter("bName"), request.getParameter("bTitle"),
//				request.getParameter("bContent"));
//		return "redirect:list";
//	}
	
	@RequestMapping("/write")
	   public String write(HttpServletRequest request, Model model) {
	      IDao dao = sqlSession.getMapper(IDao.class);
	      dao.writeDao(request.getParameter("bName"), request.getParameter("bTitle"),
	            request.getParameter("bContent"));
	      
	      return "redirect:list";
	   }
	
	@RequestMapping("/view")
	public String view() {
				
		return "/view";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.deleteDao(request.getParameter("bId"));
		return "redirect:list";
	}
	
	@RequestMapping("/modify_view")
	public String modify_view(HttpServletRequest request, Model model) {
		IDao dao = sqlSession.getMapper(IDao.class);
		ContentDto content = dao.contentDao(request.getParameter("bId"));
		model.addAttribute("content_view", content);
		
		return "modify_view";
	}
	
	@RequestMapping("/modify.do")
	public String modify(HttpServletRequest request, Model model) {	
		IDao dao = sqlSession.getMapper(IDao.class);
		String bName = request.getParameter("bName");
		String bTitle = request.getParameter("bTitle");
		String bContent = request.getParameter("bContent");
		String bId = request.getParameter("bId");
		
		dao.modifyDao(bName, bTitle, bContent, bId);
		ContentDto content = dao.contentDao(bId);
		model.addAttribute("content_view", content);
		
		return "content_view";
	}
	
	
	@RequestMapping("/reply_view")
	   public String reply_view(HttpServletRequest request, Model model) {
	      
	      IDao dao = sqlSession.getMapper(IDao.class);
	      ContentDto content = dao.contentDao(request.getParameter("bId"));
	      model.addAttribute("reply_view", content);
	      
	      return "/reply_view";
	   }
	   
	   @RequestMapping("/reply")
	   public String reply(HttpServletRequest request, Model model) {
	      IDao dao = sqlSession.getMapper(IDao.class);
	      dao.replyShape(Integer.parseInt(request.getParameter("bGroup")), Integer.parseInt(request.getParameter("bStep")));
	      dao.replyDao(request.getParameter("bName"), request.getParameter("bTitle"),
	            request.getParameter("bContent"), Integer.parseInt(request.getParameter("bGroup")), Integer.parseInt(request.getParameter("bStep")+1), Integer.parseInt(request.getParameter("bIndent")+1));
	      
	      return "redirect:list";
	   }
	
}
