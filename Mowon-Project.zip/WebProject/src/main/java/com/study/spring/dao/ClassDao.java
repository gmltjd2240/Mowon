package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.BDto;
import com.study.spring.dto.ClassDto;
import com.study.spring.dto.RegDto;


public interface ClassDao {
	
	public void LectureRegistration(String aCADEMY_NAME, String cURRICULUM_NAME, String cLASS_NAME, String cLASS_LOCATION,
			String cLASS_START, String cLASS_END, String bEACON_ID, String tEACHER_NAME, String cURRICULUM_PEIOD,
			String cURRICULUM_MONEY, String cURRICULUM_INTRODUCE, String cLASS_DAY);
	
	//강사 리스트
	public ArrayList<BDto> listDao(String ACADEMY_NAME,int endPage, int startPage);
	public ArrayList<BDto> ClistDao(String ACADEMY_NAME,String TEACHER_NAME);
	public ArrayList<BDto> AllClistDao(String ACADEMY_NAME);
	
	public ArrayList<BDto> searchlistDao(String ACADEMY_NAME, int endPage, int startPage, String search, String division);
	
	public Integer pageDao(String ACADEMY_NAME,String division,String search);
	public Integer pageDao1(String ACADEMY_NAME);

	
	
	//반 삭제
	public void ClassDelete(String aCADEMY_NAME, String cLASS_NAME);
	
	
}
