package com.study.spring.dto;

import java.sql.Timestamp;

public class CommentDto {

	int COMMENT_ID;
	int BALLID;
	String COMMENT_NAME;
	String COMMENT_CONTENT;
	Timestamp COMMENT_DATE;
	
	public CommentDto() {
		
	}
	
	public CommentDto(int cOMMENT_ID, int bALLID, String cOMMENT_NAME, String cOMMENT_CONTENT, Timestamp cOMMENT_DATE) {
		COMMENT_ID = cOMMENT_ID;
		BALLID = bALLID;
		COMMENT_NAME = cOMMENT_NAME;
		COMMENT_CONTENT = cOMMENT_CONTENT;
		COMMENT_DATE = cOMMENT_DATE;
	}

	
	
	public int getCOMMENT_ID() {
		return COMMENT_ID;
	}

	public void setCOMMENT_ID(int cOMMENT_ID) {
		COMMENT_ID = cOMMENT_ID;
	}

	public int getBALLID() {
		return BALLID;
	}

	public void setBALLID(int bALLID) {
		BALLID = bALLID;
	}

	public String getCOMMENT_NAME() {
		return COMMENT_NAME;
	}

	public void setCOMMENT_NAME(String cOMMENT_NAME) {
		COMMENT_NAME = cOMMENT_NAME;
	}

	public String getCOMMENT_CONTENT() {
		return COMMENT_CONTENT;
	}

	public void setCOMMENT_CONTENT(String cOMMENT_CONTENT) {
		COMMENT_CONTENT = cOMMENT_CONTENT;
	}

	public Timestamp getCOMMENT_DATE() {
		return COMMENT_DATE;
	}

	public void setCOMMENT_DATE(Timestamp cOMMENT_DATE) {
		COMMENT_DATE = cOMMENT_DATE;
	}
	


}