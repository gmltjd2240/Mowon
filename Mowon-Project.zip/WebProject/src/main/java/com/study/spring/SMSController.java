package com.study.spring;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Random;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.study.spring.dao.ClassDao;
import com.study.spring.dao.SMSDao;
import com.study.spring.dao.StudentDao;
import com.study.spring.dto.BPageInfo;
import com.study.spring.dto.StudentDto;

import net.nurigo.java_sdk.api.Message;
import net.nurigo.java_sdk.exceptions.CoolsmsException;

@Controller
public class SMSController {

	int listCount = 10;
	int pageCount = 10;
	String USER = "";
	String api_key = "NCSB6P9LJLS3ZY4S";
	String api_secret = "EMN19CIF2JZ28HT89UZ3KVAEWXYTFFGH";

	@Autowired
	private SqlSession sqlSession;

	@RequestMapping("/SMS")
	public String main(HttpServletRequest request, Model model) {
		String ACADEMY_NAME = request.getParameter("name");
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		ClassDao Cdao = sqlSession.getMapper(ClassDao.class);

		model.addAttribute("list", dao.StudentNameDao(ACADEMY_NAME));
		model.addAttribute("Clist", Cdao.AllClistDao(ACADEMY_NAME));

		Message coolsms = new Message(api_key, api_secret);
		try {
		      JSONObject obj = (JSONObject) coolsms.balance();
		      model.addAttribute("cash", obj.get("cash"));
		    } catch (CoolsmsException e) {
		      System.out.println(e.getMessage());
		      System.out.println(e.getCode());
		    }
		  


		return "/management/SMS/SMSPush";
	}

	// SMS발송 리스트 보기
	@RequestMapping(value = "/SMSList", method = { RequestMethod.POST, RequestMethod.GET })
	public String StudentList(HttpServletRequest request, Model model) {
		String ACADEMY_NAME = request.getParameter("name");
		SMSDao dao = sqlSession.getMapper(SMSDao.class);

		HttpSession session = null;
		session = request.getSession();

		int nPage = 1;
		try {
			String sPage = request.getParameter("page");
			nPage = Integer.parseInt(sPage);
		} catch (Exception e) {
		}

		session.setAttribute("cpage", nPage);

		BPageInfo pinfo = articlePage(request, model);
		model.addAttribute("page", pinfo);

		nPage = pinfo.getCurPage();

		int curPage = nPage;
		int nStart = (curPage - 1) * listCount + 1;
		int nEnd = (curPage - 1) * listCount + listCount;
		model.addAttribute("list", dao.listDao(ACADEMY_NAME, nEnd, nStart));

		return "/management/SMS/SMSList";
	}
	//보낸 메시지 자세히 보기
	@RequestMapping(value="/SMSDetail", method= {RequestMethod.POST,RequestMethod.GET})
	public String SMSDetail(HttpServletRequest request,Model model, HttpSession session){
		SMSDao dao = sqlSession.getMapper(SMSDao.class);
		StudentDao Sdao = sqlSession.getMapper(StudentDao.class);
		
		String ACADEMY_NAME = request.getParameter("name");
		String GROUP_TYPE = request.getParameter("GROUP_TYPE");
		String GROUP_TYPE1 = request.getParameter("GROUP_TYPE1");
		String SMS_CONTENT = request.getParameter("SMS_CONTENT");
		String GROUP_NAME = request.getParameter("GROUP_NAME");
		
		USER = "";
		//개인
		if(GROUP_TYPE1.equals("개인")) {
			ArrayList<StudentDto> solo = Sdao.StudentInfo1(ACADEMY_NAME, GROUP_NAME);
			if(GROUP_TYPE.equals("학생")) {
				model.addAttribute("Content", SMS_CONTENT);
				model.addAttribute("list", solo.get(0).getSTUDENT_NAME().toString());
			}else if(GROUP_TYPE.equals("부모")) {
				model.addAttribute("list", solo.get(0).getGUARDIAN_NAME().toString()+"(학부모)");
				model.addAttribute("Content", SMS_CONTENT);
			}else if(GROUP_TYPE.equals("전체")) {
				model.addAttribute("list", solo.get(0).getSTUDENT_NAME().toString()+","+solo.get(0).getGUARDIAN_NAME().toString()+"(학부모)");
				model.addAttribute("Content", SMS_CONTENT);
			}
		}else if(GROUP_TYPE1.equals("교실")) {
			ArrayList<StudentDto> AllClass = Sdao.ClassStudentDao(ACADEMY_NAME, GROUP_NAME);
			System.out.println(ACADEMY_NAME+":"+GROUP_NAME);
			if(GROUP_TYPE.equals("학생")) {
				for (int i = 0; i < AllClass.size(); i++) {
					if(i==0) {
						USER += AllClass.get(i).getSTUDENT_NAME().toString();
					}else {
						USER += ","+AllClass.get(i).getSTUDENT_NAME().toString();
					}
				}
				model.addAttribute("list", USER);
				model.addAttribute("Content", SMS_CONTENT);
			}else if(GROUP_TYPE.equals("부모")) {
				for (int i = 0; i < AllClass.size(); i++) {
					if(i==0) {
						USER += AllClass.get(i).getGUARDIAN_NAME().toString()+"(학부모)";
					}else {
						USER += ","+AllClass.get(i).getGUARDIAN_NAME().toString()+"(학부모)";
					}
				}
				model.addAttribute("list", USER);
				model.addAttribute("Content", SMS_CONTENT);
			}else if(GROUP_TYPE.equals("전체")) {
				for (int i = 0; i < AllClass.size(); i++) {
					if(i==0) {
						USER += AllClass.get(i).getSTUDENT_NAME().toString()+","+AllClass.get(i).getGUARDIAN_NAME().toString()+"(학부모)";
					}else {
						USER += ","+AllClass.get(i).getSTUDENT_NAME().toString()+","+AllClass.get(i).getGUARDIAN_NAME().toString()+"(학부모)";
					}
				}
			}
			model.addAttribute("list", USER);
			model.addAttribute("Content", SMS_CONTENT);
		}else if(GROUP_TYPE1.equals("전체")) {
			ArrayList<StudentDto> ALL = Sdao.StudentNameDao(ACADEMY_NAME);
			if(GROUP_TYPE.equals("학생")) {
				for (int i = 0; i < ALL.size(); i++) {
					if(i==0) {
						USER += ALL.get(i).getSTUDENT_NAME().toString();
					}else {
						USER += ","+ALL.get(i).getSTUDENT_NAME().toString();
					}
				}
				model.addAttribute("list", USER);
				model.addAttribute("Content", SMS_CONTENT);
			}else if(GROUP_TYPE.equals("부모")) {
				for (int i = 0; i < ALL.size(); i++) {
					if(i==0) {
						USER += ALL.get(i).getGUARDIAN_NAME().toString()+"(학부모)";
					}else {
						USER += ","+ALL.get(i).getGUARDIAN_NAME().toString()+"(학부모)";
					}
				}
				model.addAttribute("list", USER);
				model.addAttribute("Content", SMS_CONTENT);
			}else if(GROUP_TYPE.equals("전체")) {
				for (int i = 0; i < ALL.size(); i++) {
					if(i==0) {
						USER += ALL.get(i).getSTUDENT_NAME().toString()+","+ALL.get(i).getGUARDIAN_NAME().toString()+"(학부모)";
					}else {
						USER += ","+ALL.get(i).getSTUDENT_NAME().toString()+","+ALL.get(i).getGUARDIAN_NAME().toString()+"(학부모)";
					}
				}
				model.addAttribute("list", USER);
				model.addAttribute("Content", SMS_CONTENT);
			}
		}

		
	     return "/management/SMS/SMSDetail";
	}

	@RequestMapping(value = "/sendSms")
	public String sendSms(HttpServletRequest request, Model model) throws Exception {
		Coolsms coolsms = new Coolsms(api_key, api_secret);

		String ACADEMY_NAME = request.getParameter("name");
		String submitType = request.getParameter("submitType");
		String submitType1 = request.getParameter("submitType1");
		String GET_SMS = request.getParameter("GET_SMS");
		String SMS_CONTENT = request.getParameter("SMS_CONTENT");
		String sTel = request.getParameter("sTel");
		String gTel = request.getParameter("gTel");

		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		SMSDao Sdao = sqlSession.getMapper(SMSDao.class);
		HashMap<String, String> set = new HashMap<String, String>();
		set.put("from", "01097602240"); // 발신번호
		// 전체 메시지
		if (submitType.equals("전체")) {
			ArrayList<StudentDto> ALL = dao.StudentNameDao(ACADEMY_NAME);
			if (submitType1.equals("학생")) {
				for (int i = 0; i < ALL.size(); i++) {
					set.put("to", ALL.get(i).getSTUDENT_TEL().toString()); // 수신번호
					set.put("text", SMS_CONTENT); // 문자내용
					set.put("type", "sms"); // 문자 타입
					coolsms.send(set);
				}
				Sdao.SMSPushData(ACADEMY_NAME, submitType1,
						ALL.get(0).getSTUDENT_NAME().toString() + "님 외 " + ALL.size() + "명", SMS_CONTENT,submitType,GET_SMS);
			} else if (submitType1.equals("부모")) {
				for (int i = 0; i < ALL.size(); i++) {
					set.put("to", ALL.get(i).getGUARDIAN_TEL().toString()); // 수신번호
					set.put("text", SMS_CONTENT); // 문자내용
					set.put("type", "sms"); // 문자 타입
					coolsms.send(set);
				}
				Sdao.SMSPushData(ACADEMY_NAME, submitType1,
						ALL.get(0).getGUARDIAN_NAME().toString() + "님 외 " + ALL.size() + "명", SMS_CONTENT,submitType,GET_SMS);
			} else if (submitType1.equals("전체")) {
				for (int i = 0; i < ALL.size(); i++) {
					set.put("to", ALL.get(i).getSTUDENT_TEL().toString()); // 수신번호
					set.put("text", SMS_CONTENT); // 문자내용
					set.put("type", "sms"); // 문자 타입
					coolsms.send(set);
					set.put("to", ALL.get(i).getGUARDIAN_TEL().toString()); // 수신번호
					set.put("text", SMS_CONTENT); // 문자내용
					set.put("type", "sms"); // 문자 타입
					coolsms.send(set);
				}
				Sdao.SMSPushData(ACADEMY_NAME, submitType1,
						ALL.get(0).getSTUDENT_NAME().toString() + "님 외 " + (ALL.size() * 2) + "명", SMS_CONTENT,submitType,GET_SMS);
			}
		} else if (submitType.equals("교실")) {
			ArrayList<StudentDto> AllClass = dao.ClassStudentDao(ACADEMY_NAME, GET_SMS);
			if (submitType1.equals("학생")) {
				for (int i = 0; i < AllClass.size(); i++) {
					System.out.println(AllClass.get(i).getSTUDENT_TEL().toString());
					System.out.println(SMS_CONTENT);
					set.put("to", AllClass.get(i).getSTUDENT_TEL().toString()); // 수신번호
					set.put("text", SMS_CONTENT); // 문자내용
					set.put("type", "sms"); // 문자 타입
					coolsms.send(set);
				}
				Sdao.SMSPushData(ACADEMY_NAME, submitType1,
						AllClass.get(0).getSTUDENT_NAME().toString() + "님 외 " + AllClass.size() + "명", SMS_CONTENT,submitType,GET_SMS);
			} else if (submitType1.equals("부모")) {
				for (int i = 0; i < AllClass.size(); i++) {
					set.put("to", AllClass.get(i).getGUARDIAN_TEL().toString()); // 수신번호
					set.put("text", SMS_CONTENT); // 문자내용
					set.put("type", "sms"); // 문자 타입
					coolsms.send(set);
				}
				Sdao.SMSPushData(ACADEMY_NAME, submitType1,
						AllClass.get(0).getGUARDIAN_NAME().toString() + "님 외 " + AllClass.size() + "명", SMS_CONTENT,submitType,GET_SMS);
			} else if (submitType1.equals("전체")) {
				for (int i = 0; i < AllClass.size(); i++) {
					set.put("to", AllClass.get(i).getSTUDENT_TEL().toString()); // 수신번호
					set.put("text", SMS_CONTENT); // 문자내용
					set.put("type", "sms"); // 문자 타입
					coolsms.send(set);
					set.put("to", AllClass.get(i).getGUARDIAN_TEL().toString()); // 수신번호
					set.put("text", SMS_CONTENT); // 문자내용
					set.put("type", "sms"); // 문자 타입
					coolsms.send(set);
				}
				Sdao.SMSPushData(ACADEMY_NAME, submitType1,
						AllClass.get(0).getSTUDENT_NAME().toString() + "님 외 " + (AllClass.size() * 2) + "명",
						SMS_CONTENT,submitType,GET_SMS);
			}
		} else if (submitType.equals("개인")) {
			if (submitType1.equals("학생")) {
				set.put("to", sTel); // 수신번호
				set.put("text", SMS_CONTENT); // 문자내용
				set.put("type", "sms"); // 문자 타입
				coolsms.send(set);
				Sdao.SMSPushData(ACADEMY_NAME, submitType1, GET_SMS, SMS_CONTENT,submitType,sTel);
			} else if (submitType1.equals("부모")) {
				set.put("to", gTel); // 수신번호
				set.put("text", SMS_CONTENT); // 문자내용
				set.put("type", "sms"); // 문자 타입
				coolsms.send(set);
				Sdao.SMSPushData(ACADEMY_NAME, submitType1, GET_SMS, SMS_CONTENT,submitType,sTel);
			} else if (submitType1.equals("전체")) {
				set.put("to", sTel); // 수신번호
				set.put("text", SMS_CONTENT); // 문자내용
				set.put("type", "sms"); // 문자 타입
				coolsms.send(set);
				set.put("to", gTel); // 수신번호
				set.put("text", SMS_CONTENT); // 문자내용
				set.put("type", "sms"); // 문자 타입
				coolsms.send(set);
				Sdao.SMSPushData(ACADEMY_NAME, submitType1, GET_SMS + "외 1명", SMS_CONTENT,submitType,sTel);
			}
		}
		ClassDao Cdao = sqlSession.getMapper(ClassDao.class);

		model.addAttribute("list", dao.StudentNameDao(ACADEMY_NAME));
		model.addAttribute("Clist", Cdao.AllClistDao(ACADEMY_NAME));

		ACADEMY_NAME = URLEncoder.encode(ACADEMY_NAME, "UTF-8");

		return "redirect:SMSList?name=" + ACADEMY_NAME;
	}

	// 잔액정보


	public class Coolsms extends Https {
		final String URL = "https://api.coolsms.co.kr";
		private String sms_url = URL + "/sms/1.5/";
		private String senderid_url = URL + "/senderid/1.1/";
		private String api_key;
		private String api_secret;
		private String timestamp;
		private Https https = new Https();
		Properties properties = System.getProperties();

		/*
		 * Set api_key, api_secret
		 */
		public Coolsms(String api_key, String api_secret) {
			this.api_key = api_key;
			this.api_secret = api_secret;
		}

		/*
		 * Send messages
		 * 
		 * @param set : HashMap<String, String>
		 */
		@SuppressWarnings("unchecked")
		public JSONObject send(HashMap<String, String> params) {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				params = setBasicInfo(params);
				params.put("os_platform", properties.getProperty("os_name"));
				params.put("dev_lang", "JAVA " + properties.getProperty("java.version"));
				params.put("sdk_version", "JAVA SDK 1.1");

				// Send message
				response = https.postRequest(sms_url + "send", params);
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Sent messages
		 * 
		 * @param set : HashMap<String, String>
		 */
		@SuppressWarnings("unchecked")
		public JSONObject sent(HashMap<String, String> params) {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				params = setBasicInfo(params);

				response = https.request(sms_url + "sent", params); // GET방식 전송
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Reserve message cancel
		 * 
		 * @param set : HashMap<String, String>
		 */
		@SuppressWarnings("unchecked")
		public JSONObject cancel(HashMap<String, String> params) {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				params = setBasicInfo(params);

				// Cancel reserve message
				response = https.postRequest(sms_url + "cancel", params);

				// Cancel은 response 가 empty 면 성공
				if (response.get("message") == "response is empty") {
					response.put("status", "true");
					response.put("message", null);
				}
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Balance info
		 */
		public JSONObject balance() {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				HashMap<String, String> params = new HashMap<String, String>();
				params = setBasicInfo(params);

				// GET방식 전송
				response = https.request(sms_url + "balance", params); // GET방식 전송
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Register sender number
		 * 
		 * @param set : HashMap<String, String>
		 */
		public JSONObject register(HashMap<String, String> params) {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				params = setBasicInfo(params);

				// Register sender number request
				response = https.postRequest(senderid_url + "register", params);
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Verify sender number
		 * 
		 * @param set : HashMap<String, String>
		 */
		public JSONObject verify(HashMap<String, String> params) {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				params = setBasicInfo(params);

				// Register verify sender number
				response = https.postRequest(senderid_url + "verify", params);
				if (response.get("message") == "response is empty") {
					response.put("status", "true");
					response.put("message", null);
				}
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Delete sender number
		 * 
		 * @param set : HashMap<String, String>
		 */
		public JSONObject delete(HashMap<String, String> params) {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				params = setBasicInfo(params);

				// Register delete sender number
				response = https.postRequest(senderid_url + "delete", params);
				if (response.get("message") == "response is empty") {
					response.put("status", "true");
					response.put("message", null);
				}
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Set default sender number
		 * 
		 * @param set : HashMap<String, String>
		 */
		public JSONObject setDefault(HashMap<String, String> params) {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				params = setBasicInfo(params);

				// Register set default sender number
				response = https.postRequest(senderid_url + "set_default", params);
				if (response.get("message") == "response is empty") {
					response.put("status", "true");
					response.put("message", null);
				}
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Get sender number list
		 * 
		 * @param set : HashMap<String, String>
		 */
		public JSONObject list() {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				HashMap<String, String> params = new HashMap<String, String>();
				params = setBasicInfo(params);

				// Register sender number request
				response = https.request(senderid_url + "list", params);
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Get default sender number
		 * 
		 * @param set : HashMap<String, String>
		 */
		public JSONObject getDefault() {
			JSONObject response = new JSONObject();
			try {
				// 기본정보 입력
				HashMap<String, String> params = new HashMap<String, String>();
				params = setBasicInfo(params);

				// Get default sender number
				response = https.request(senderid_url + "get_default", params);
			} catch (Exception e) {
				response.put("status", false);
				response.put("message", e.toString());
			}
			return response;
		}

		/*
		 * Set api_key and api_secret.
		 * 
		 * @param set : HashMap<String, String>
		 */
		private HashMap<String, String> setBasicInfo(HashMap<String, String> params) {
			params.put("api_secret", this.api_secret);
			params.put("api_key", this.api_key);
			return params;
		}
	}

	public class Https {
		/*
		 * postRequest (POST)
		 * 
		 * @param StringBuffer : data
		 * 
		 * @param String : image
		 */
		public JSONObject postRequest(String url_string, HashMap<String, String> params) {
			JSONObject obj = new JSONObject();
			try {
				obj.put("status", false);

				String salt = salt();
				String timestamp = getTimestamp();
				String signature = getSignature(params.get("api_secret"), salt, timestamp);
				String boundary = salt + timestamp;
				String delimiter = "\r\n--" + boundary + "\r\n";

				params.put("salt", salt);
				params.put("signature", signature);
				params.put("timestamp", timestamp);

				// data 생성 및 데이터 구분을 위한 delimiter 설정
				StringBuffer postDataBuilder = new StringBuffer();
				postDataBuilder.append(delimiter);

				// params에 image가 있으면 변수에 담아 request를 다르게 보낸다
				String image = null;
				String image_path = null;
				for (Entry<String, String> entry : params.entrySet()) {
					String key = entry.getKey();
					String value = entry.getValue();

					if (key == "image") {
						image = value;
						continue;
					}
					if (key == "image_path") {
						image_path = value;
						continue;
					}
					postDataBuilder = setPostData(postDataBuilder, key, value, delimiter);
					if (postDataBuilder == null) {
						obj.put("message", "postRequest data build fail");
						return obj;
					}
				}

				URL url = new URL(url_string);
				HttpsURLConnection connection = (HttpsURLConnection) url.openConnection(); // connect
				connection.setDoInput(true);
				connection.setDoOutput(true);
				connection.setRequestMethod("POST");
				connection.setRequestProperty("Connection", "Keep-Alive");
				connection.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
				connection.setUseCaches(false);
				DataOutputStream outputStream = new DataOutputStream(
						new BufferedOutputStream(connection.getOutputStream()));

				// image data set
				if (image != null) {
					// MMS Setting
					if (image_path == null)
						image_path = "./";

					// image file set
					postDataBuilder.append(setFile("image", image));
					postDataBuilder.append("\r\n");
					FileInputStream fileStream = new FileInputStream(image_path + image);
					outputStream.writeUTF(postDataBuilder.toString());

					// 파일전송 작업 시작
					int maxBufferSize = 1024;
					int bufferSize = Math.min(fileStream.available(), maxBufferSize);
					byte[] buffer = new byte[bufferSize];
					// 버퍼 크기만큼 파일로부터 바이트 데이터를 읽는다
					int byteRead = fileStream.read(buffer, 0, bufferSize);
					// 전송
					while (byteRead > 0) {
						outputStream.write(buffer);
						bufferSize = Math.min(fileStream.available(), maxBufferSize);
						byteRead = fileStream.read(buffer, 0, bufferSize);
					}
					fileStream.close();
				} else {
					outputStream.writeUTF(postDataBuilder.toString());
				}
				outputStream.writeBytes(delimiter);
				outputStream.flush();
				outputStream.close();

				String response = null;
				String inputLine;
				int response_code = connection.getResponseCode();
				BufferedReader in = null;
				// response 담기
				if (response_code != 200) {
					in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
				} else {
					in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				}

				while ((inputLine = in.readLine()) != null) {
					response = inputLine;
				}

				if (response != null) {
					obj = (JSONObject) JSONValue.parse(response);
					obj.put("status", "true");
					if (obj.get("code") != null) {
						obj.put("status", false);
					}
				} else {
					obj.put("status", false);
					obj.put("message", "response is empty");
				}
			} catch (Exception e) {
				obj.put("status", false);
				obj.put("message", e.toString());
			}
			return obj;
		}

		/*
		 * https request (GET)
		 */
		public JSONObject request(String url_string, HashMap<String, String> params) {
			JSONObject obj = new JSONObject();
			try {
				obj.put("status", "true");
				String charset = "UTF8";
				String salt = salt();
				String timestamp = getTimestamp();
				String signature = getSignature(params.get("api_secret"), salt, timestamp); // getSignature

				String data = url_string + "?";
				data = data + URLEncoder.encode("api_key", charset) + "="
						+ URLEncoder.encode(params.get("api_key"), charset);
				data = setGetData(data, "signature", signature, charset);
				data = setGetData(data, "salt", salt, charset);
				data = setGetData(data, "timestamp", timestamp, charset);

				params.remove("api_secret");

				for (Entry<String, String> entry : params.entrySet()) {
					String key = entry.getKey();
					String value = entry.getValue();
					data = setGetData(data, key, value, charset);
					if (data == null) {
						obj.put("status", false);
						obj.put("message", "request data build fail");
						return obj;
					}
				}

				URL url = new URL(data);
				HttpsURLConnection connection = (HttpsURLConnection) url.openConnection(); // connect
				connection.setRequestMethod("GET");

				BufferedReader in = null;
				int response_code = connection.getResponseCode();
				if (response_code != 200) {
					// 오류발생시
					in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
				} else {
					in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				}

				String response = null;
				String inputLine; // 서버로 부터 받은 response를 받을 변수
				while ((inputLine = in.readLine()) != null) {
					response = inputLine;
				}

				if (response != null) {
					// response 가 object 냐 array에 따라 parse를 다르게한다.
					try {
						obj = (JSONObject) JSONValue.parse(response);
					} catch (Exception e) {
						try {
							JSONArray reponse_array = (JSONArray) JSONValue.parse(response);
							obj.put("data", reponse_array);
						} catch (Exception ex) {
							obj.put("status", false);
						}
					}
					obj.put("status", "true");
					if (obj.get("code") != null) {
						obj.put("status", false);
					}
				} else {
					obj.put("status", false);
					obj.put("message", "response is empty");
				}
			} catch (Exception e) {
				obj.put("status", false);
				obj.put("message", e.toString());
			}
			return obj;
		}

		/*
		 * 업로드할 파일에 대한 메타 데이터를 설정한다.
		 * 
		 * @param key : 서버에서 사용할 파일 변수명
		 * 
		 * @param fileName : 서버에서 저장될 파일명
		 */
		public String setFile(String key, String fileName) {
			return "Content-Disposition: form-data; name=\"" + key + "\";filename=\"" + fileName
					+ "\"\r\nContent-type: image/jpeg;\r\n";
		}

		/*
		 * String을 POST 형식에 맞게 Input
		 */
		public StringBuffer setPostData(StringBuffer builder, String key, String value, String delimiter) {
			try {
				builder.append(setValue(key, value));
				builder.append(delimiter);
			} catch (Exception e) {
				return null;
			}

			return builder;
		}

		/*
		 * String을 GET 방식으로 변경
		 */
		public String setGetData(String data, String key, String value, String charSet) {
			try {
				data += "&" + URLEncoder.encode(key, charSet) + "=" + URLEncoder.encode(value, charSet);
			} catch (Exception e) {
				return null;
			}

			return data;
		}

		/*
		 * Get salt
		 */
		public String salt() {
			String uniqId = "";
			Random randomGenerator = new Random();

			// length - set the unique Id length
			for (int length = 1; length <= 10; ++length) {
				int randomInt = randomGenerator.nextInt(10); // digit range from 0 - 9
				uniqId += randomInt + "";
			}

			return uniqId;
		}

		/*
		 * Get signature
		 */
		public String getSignature(String api_secret, String salt, String timestamp) {
			String signature = "";

			try {
				String temp = timestamp + salt;
				SecretKeySpec keySpec = new SecretKeySpec(api_secret.getBytes(), "HmacMD5");
				Mac mac = Mac.getInstance("HmacMD5");
				mac.init(keySpec);

				byte[] result = mac.doFinal(temp.getBytes());
				char[] hexArray = "0123456789ABCDEF".toCharArray();
				char[] hexChars = new char[result.length * 2];

				for (int i = 0; i < result.length; i++) {
					int positive = result[i] & 0xff;
					hexChars[i * 2] = hexArray[positive >>> 4];
					hexChars[i * 2 + 1] = hexArray[positive & 0x0F];
				}
				signature = new String(hexChars);
			} catch (Exception e) {
				signature = e.getMessage();
			}

			return signature;
		}

		/*
		 * Get timestamp
		 */
		public String getTimestamp() {
			long timestamp_long = System.currentTimeMillis() / 1000;
			String timestamp = Long.toString(timestamp_long);
			return timestamp;
		}

		/*
		 * Map 형식으로 Key와 Value를 셋팅한다.
		 * 
		 * @param key : 서버에서 사용할 변수명
		 * 
		 * @param value : 변수명에 해당하는 실제 값
		 */
		public String setValue(String key, String value) {
			return "Content-Disposition: form-data; name=\"" + key + "\"\r\n\r\n" + value;
		}
	}

	public BPageInfo articlePage(HttpServletRequest request, Model model) {

		SMSDao dao = sqlSession.getMapper(SMSDao.class);
		int totalCount = 0;
		String ACADEMY_NAME = request.getParameter("name");
		HttpSession session = null;
		session = request.getSession();

		int curPage = 1;

		try {
			String sPage = request.getParameter("page");
			curPage = Integer.parseInt(sPage);

			if (session.getAttribute("cpage") != null) {
				curPage = (Integer) session.getAttribute("cpage");
			}
		} catch (Exception e) {
		}

		totalCount = dao.pageDao1(ACADEMY_NAME).intValue();
		int totalPage = totalCount / listCount;
		if (totalCount % listCount > 0)
			totalPage++;

		int myCurPage = curPage;
		if (myCurPage > totalPage)
			myCurPage = totalPage;
		if (myCurPage < 1)
			myCurPage = 1;

		int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;

		int endPage = startPage + pageCount + 1;
		if (endPage > totalPage)
			endPage = totalPage;

		BPageInfo pinfo = new BPageInfo();
		// set
		pinfo.setTotalCount(totalCount);
		pinfo.setListCount(listCount);
		pinfo.setTotalPage(totalPage);
		pinfo.setCurPage(myCurPage);
		pinfo.setPageCount(pageCount);
		pinfo.setStartPage(startPage);
		pinfo.setEndPage(endPage);

		return pinfo;

	}

}
