package com.study.spring.dto;

import java.sql.Timestamp;

public class BAccount {

	String aId;
	String aPw;
	String aName;
	String aTel;
	String aAddress;
	Timestamp rDate;
	String mName;
	String mTel;
	
	public BAccount() {
		
	}
	
	public BAccount(String aId, String aPw, String aName, String aTel, String aAddress,
			Timestamp rDate, String mName, String mTel) {
		this.aId = aId;
		this.aPw = aPw;
		this.aName = aName;
		this.aTel = aTel;
		this.aAddress = aAddress;
		this.rDate = rDate;
		this.mName = mName;
		this.mTel = mTel;
	}

	public String getaId() {
		return aId;
	}

	public void setaId(String aId) {
		this.aId = aId;
	}

	public String getaPw() {
		return aPw;
	}

	public void setaPw(String aPw) {
		this.aPw = aPw;
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}

	public String getaTel() {
		return aTel;
	}

	public void setaTel(String aTel) {
		this.aTel = aTel;
	}

	public String getaAddress() {
		return aAddress;
	}

	public void setaAddress(String aAddress) {
		this.aAddress = aAddress;
	}

	public Timestamp getrDate() {
		return rDate;
	}

	public void setrDate(Timestamp rDate) {
		this.rDate = rDate;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getmTel() {
		return mTel;
	}

	public void setmTel(String mTel) {
		this.mTel = mTel;
	}

}