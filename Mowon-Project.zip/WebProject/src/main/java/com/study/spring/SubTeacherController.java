package com.study.spring;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.study.spring.dao.ClassDao;
import com.study.spring.dao.StudentDao;
import com.study.spring.dao.TeacherDao;
import com.study.spring.dto.BPageInfo;

@Controller
public class SubTeacherController {
	
	int listCount = 10;	
	int pageCount = 10;
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/registration")
	public String registration() {

		return "/management/Teacher/registration";
	}
	
	@RequestMapping(value="/TeacherDetail", method= {RequestMethod.POST,RequestMethod.GET})
	public String TeacherDetail(HttpServletRequest request,Model model, HttpSession session){
		TeacherDao dao = sqlSession.getMapper(TeacherDao.class);
		ClassDao Cdao = sqlSession.getMapper(ClassDao.class);
		StudentDao Sdao = sqlSession.getMapper(StudentDao.class);
		
		String TEACHER_NAME = request.getParameter("TEACHER_NAME");
		String ACADEMY_NAME = request.getParameter("name");
		String CLASS_NAME = request.getParameter("CLASS_NAME");
		

		
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
		session.setAttribute("cpage", nPage);
		
		BPageInfo pinfo = articlePage1(request, model);
	    model.addAttribute("page", pinfo);
	      
	    nPage = pinfo.getCurPage();
	      
	      int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
		
		System.out.println(TEACHER_NAME+":::g::"+ACADEMY_NAME);
		
		model.addAttribute("classname", CLASS_NAME);
		model.addAttribute("teachername", TEACHER_NAME);
		model.addAttribute("Clist", Cdao.ClistDao(ACADEMY_NAME,TEACHER_NAME));
		model.addAttribute("Slist", Sdao.ClasslistDao(ACADEMY_NAME,CLASS_NAME,nEnd, nStart));
		model.addAttribute("Tinfo", dao.TeacherInfo(ACADEMY_NAME, TEACHER_NAME));
		
	      return "/management/Teacher/TeacherDetail";
	}
	
	@RequestMapping(value="/TeacherList", method= {RequestMethod.POST,RequestMethod.GET})
	public String TeacherList(HttpServletRequest request, Model model) {
		TeacherDao dao = sqlSession.getMapper(TeacherDao.class);
		String ACADEMY_NAME = request.getParameter("name");
		
		HttpSession session = null;
		session = request.getSession();
		
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
		session.setAttribute("cpage", nPage);
		
		BPageInfo pinfo = articlePage(request, model);
	    model.addAttribute("page", pinfo);
	      
	    nPage = pinfo.getCurPage();
	    
	    int curPage = nPage;
		int nStart = (curPage - 1) * listCount + 1;
		int nEnd = (curPage - 1) * listCount + listCount;
	    
		String search = request.getParameter("search");
		
		if(search == null || search.equals("")) {
			model.addAttribute("list", dao.listDao(ACADEMY_NAME,nEnd, nStart));
			return "/management/Teacher/TeacherList";
		}else {
			model.addAttribute("search1", request.getParameter("search"));
			model.addAttribute("division1", request.getParameter("division"));
			model.addAttribute("list", dao.searchlistDao(ACADEMY_NAME,nEnd, nStart,request.getParameter("division"),request.getParameter("search")));
			return "/management/Teacher/TeacherList";
		}
	}
	//---------------------강사등록--------------------------------
	@RequestMapping(value="/teacherSubmit",method= RequestMethod.POST)
	public String teacherSubmit(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		
		TeacherDao dao = sqlSession.getMapper(TeacherDao.class);
		dao.TeacherRegistration(request.getParameter("ACADEMY_NAME"), request.getParameter("CLASS_NAME"), request.getParameter("TEACHER_NAME"),
				request.getParameter("TEACHER_TEL"), request.getParameter("TEACHER_GENDER"), 
				request.getParameter("TEACHER_BIRTH")+"년"+request.getParameter("TEACHER_BIRTH1")+"월"+request.getParameter("TEACHER_BIRTH2")+"일",
				request.getParameter("TEACHER_EMAIL"), request.getParameter("TEACHER_SUBJECT"), request.getParameter("TEACHER_ENDSCHOOL"),
				request.getParameter("TEACHER_MAJOR"), request.getParameter("TEACHER_INTRODUCE"), request.getParameter("TEACHER_CAREER"), request.getParameter("TEACHER_PW"));
		
		String ACADEMY_NAME = request.getParameter("name");
		
		ACADEMY_NAME = URLEncoder.encode(ACADEMY_NAME, "UTF-8");

		return "redirect:TeacherList?name="+ACADEMY_NAME;
	}
	
	//강사 정보수정-----------------------------------------------------------------------
	@RequestMapping(value="/TeacherModify",method= RequestMethod.POST)
	public String TeacherModify(HttpServletRequest request, Model model) {
		
		System.out.println(request.getParameter("ACADEMY_NAME")+"   "+ request.getParameter("TEACHER_NAME")+"   "+request.getParameter("TEACHER_TEL")+"   "+ request.getParameter("TEACHER_GENDER")+"    "+
				request.getParameter("TEACHER_EMAIL")+"   "+ request.getParameter("TEACHER_SUBJECT")+"   "+ request.getParameter("TEACHER_ENDSCHOOL")+"   "+
				request.getParameter("TEACHER_MAJOR")+"   "+ request.getParameter("TEACHER_INTRODUCE")+"   "+ request.getParameter("TEACHER_CAREER")+"   "+ request.getParameter("TEACHER_PW"));
		TeacherDao dao = sqlSession.getMapper(TeacherDao.class);
		dao.TeacherInfoModify(request.getParameter("ACADEMY_NAME"), request.getParameter("TEACHER_NAME"),request.getParameter("TEACHER_TEL"), request.getParameter("TEACHER_GENDER"),
				request.getParameter("TEACHER_EMAIL"), request.getParameter("TEACHER_SUBJECT"), request.getParameter("TEACHER_ENDSCHOOL"),
				request.getParameter("TEACHER_MAJOR"), request.getParameter("TEACHER_INTRODUCE"), request.getParameter("TEACHER_CAREER"), request.getParameter("TEACHER_PW"));
		
		ClassDao Cdao = sqlSession.getMapper(ClassDao.class);
		
		String TEACHER_NAME = request.getParameter("TEACHER_NAME");
		String ACADEMY_NAME = request.getParameter("ACADEMY_NAME");
		
		model.addAttribute("Clist", Cdao.ClistDao(ACADEMY_NAME,TEACHER_NAME));
		model.addAttribute("Tinfo", dao.TeacherInfo(ACADEMY_NAME, TEACHER_NAME));

	      return "/management/Teacher/TeacherDetail";
	}
	
	//검색
	
	@RequestMapping(value="/Tsearchs", method= {RequestMethod.POST,RequestMethod.GET})
	public String Tsearchs(HttpServletRequest request,Model model, HttpSession session){
		TeacherDao dao = sqlSession.getMapper(TeacherDao.class);
		
		int nPage = 1;
	      try {
	            String sPage = request.getParameter("page");
	            nPage = Integer.parseInt(sPage);
	         } catch (Exception e) {
	            
	         }
	      BPageInfo pinfo = articlePage(request, model);
	      model.addAttribute("page", pinfo);
	      
	      nPage = pinfo.getCurPage();
	      
	      int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
	      
	      String a =  request.getParameter("search");
	      String b =  request.getParameter("division");
	      
	      
	      model.addAttribute("search1", a);
	      model.addAttribute("division1", b);
	      model.addAttribute("list", dao.searchlistDao(request.getParameter("name"), nEnd, nStart,request.getParameter("division"),request.getParameter("search")));

	      return "/management/Teacher/TeacherList";
	}
	
	
	public BPageInfo articlePage(HttpServletRequest request, Model model) {
		
		TeacherDao dao = sqlSession.getMapper(TeacherDao.class);
		int totalCount = 0;
		String ACADEMY_NAME = request.getParameter("name");
		System.out.println(ACADEMY_NAME+":::zzzzz");
		String search = "";
		search = request.getParameter("search");
		System.out.println(search+"zzzzz");
		String division = "";
		division = request.getParameter("division");
		System.out.println(division+"zzzzz");
		
		HttpSession session = null;
	    session = request.getSession();
	      
	    int curPage = 1;
	      
		try {
	         String sPage = request.getParameter("page");
	         curPage = Integer.parseInt(sPage);
	         
	         if (session.getAttribute("cpage") != null) {
	            curPage = (Integer) session.getAttribute("cpage");
	         }
	      } catch (Exception e) {
	      }
		
		
		if(search == null || search.equals("")) {
			totalCount = dao.pageDao1(ACADEMY_NAME).intValue();
			int totalPage = totalCount / listCount;
			if (totalCount % listCount > 0)
				totalPage++;
			
			int myCurPage = curPage;
			if (myCurPage > totalPage)
				myCurPage = totalPage;
			if (myCurPage < 1)
				myCurPage = 1;
			
			int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
			
			int endPage = startPage + pageCount + 1;
			if (endPage > totalPage)
				endPage = totalPage;
			
			BPageInfo pinfo = new BPageInfo();
			// set
			pinfo.setTotalCount(totalCount);
			pinfo.setListCount(listCount);
			pinfo.setTotalPage(totalPage);
			pinfo.setCurPage(myCurPage);
			pinfo.setPageCount(pageCount);
			pinfo.setStartPage(startPage);
			pinfo.setEndPage(endPage);
			
			return pinfo;
		}else {
			 totalCount = dao.pageDao(ACADEMY_NAME,division,search).intValue();
			 int totalPage = totalCount / listCount;
				if (totalCount % listCount > 0)
					totalPage++;
				
				int myCurPage = curPage;
				if (myCurPage > totalPage)
					myCurPage = totalPage;
				if (myCurPage < 1)
					myCurPage = 1;
				
				int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
				
				int endPage = startPage + pageCount + 1;
				if (endPage > totalPage)
					endPage = totalPage;
				
				BPageInfo pinfo = new BPageInfo();
				// set
				pinfo.setTotalCount(totalCount);
				pinfo.setListCount(listCount);
				pinfo.setTotalPage(totalPage);
				pinfo.setCurPage(myCurPage);
				pinfo.setPageCount(pageCount);
				pinfo.setStartPage(startPage);
				pinfo.setEndPage(endPage);
				
				return pinfo;
		}
		
	}

	public BPageInfo articlePage1(HttpServletRequest request, Model model) {
		
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		int totalCount = 0;
		String ACADEMY_NAME = request.getParameter("name");
		String CLASS_NAME = request.getParameter("CLASS_NAME");
		
		HttpSession session = null;
	    session = request.getSession();
	      
	    int curPage = 1;
	      
		try {
	         String sPage = request.getParameter("page");
	         curPage = Integer.parseInt(sPage);
	         
	         if (session.getAttribute("cpage") != null) {
	            curPage = (Integer) session.getAttribute("cpage");
	         }
	      } catch (Exception e) {
	      }
		
			totalCount = dao.pageDao2(ACADEMY_NAME,CLASS_NAME).intValue();
			int totalPage = totalCount / listCount;
			if (totalCount % listCount > 0)
				totalPage++;
			
			int myCurPage = curPage;
			if (myCurPage > totalPage)
				myCurPage = totalPage;
			if (myCurPage < 1)
				myCurPage = 1;
			
			int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
			
			int endPage = startPage + pageCount + 1;
			if (endPage > totalPage)
				endPage = totalPage;
			
			BPageInfo pinfo = new BPageInfo();
			// set
			pinfo.setTotalCount(totalCount);
			pinfo.setListCount(listCount);
			pinfo.setTotalPage(totalPage);
			pinfo.setCurPage(myCurPage);
			pinfo.setPageCount(pageCount);
			pinfo.setStartPage(startPage);
			pinfo.setEndPage(endPage);
			
			return pinfo;
		
	}

}
