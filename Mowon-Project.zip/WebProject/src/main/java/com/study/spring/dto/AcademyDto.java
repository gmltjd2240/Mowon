package com.study.spring.dto;

public class AcademyDto {
	
	String ACADEMY_ID;
	String ACADEMY_PW;
	String ACADEMY_NAME;
	String ACADEMY_TEL;
	String ACADEMY_ADDRESS;
	String MANAGER_NAME;
	String MANAGER_TEL;
	
	// 학원정보 확인 및 수정 시 들고올 추가 데이터 E-MAIL, 홈페이지
	String ACADEMY_EMAIL;
	String HOMEPAGE;
	String ACADEMY_INTRODUCE;

	public AcademyDto() {
	}
			
	public AcademyDto(String aCADEMY_ID, String aCADEMY_PW, String aCADEMY_NAME, String aCADEMY_TEL, String aCADEMY_ADDRESS,
			String mANAGER_NAME, String mANAGER_TEL, String ACADEMY_EMAIL, String HOMEPAGE, String ACADEMY_INTRODUCE){
		this.ACADEMY_ID = aCADEMY_ID;
		this.ACADEMY_PW = aCADEMY_PW;
		this.ACADEMY_NAME = aCADEMY_NAME;
		this.ACADEMY_TEL = aCADEMY_TEL;
		this.ACADEMY_ADDRESS = aCADEMY_ADDRESS;
		this.MANAGER_NAME = mANAGER_NAME;
		this.MANAGER_TEL = mANAGER_TEL;
		this.ACADEMY_EMAIL = ACADEMY_EMAIL;
		this.HOMEPAGE = HOMEPAGE;
		this.ACADEMY_INTRODUCE = ACADEMY_INTRODUCE;
		
	}

	public String getACADEMY_ID() {
		return ACADEMY_ID;
	}

	public void setACADEMY_ID(String aCADEMY_ID) {
		ACADEMY_ID = aCADEMY_ID;
	}
	
	public String getACADEMY_PW() {
		return ACADEMY_PW;
	}

	public void setACADEMY_PW(String aCADEMY_PW) {
		ACADEMY_PW = aCADEMY_PW;
	}

	public String getACADEMY_NAME() {
		return ACADEMY_NAME;
	}

	public void setACADEMY_NAME(String aCADEMY_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
	}

	public String getACADEMY_TEL() {
		return ACADEMY_TEL;
	}

	public void setACADEMY_TEL(String aCADEMY_TEL) {
		ACADEMY_TEL = aCADEMY_TEL;
	}

	public String getACADEMY_ADDRESS() {
		return ACADEMY_ADDRESS;
	}

	public void setACADEMY_ADDRESS(String aCADEMY_ADDRESS) {
		ACADEMY_ADDRESS = aCADEMY_ADDRESS;
	}

	public String getMANAGER_NAME() {
		return MANAGER_NAME;
	}

	public void setMANAGER_NAME(String mANAGER_NAME) {
		MANAGER_NAME = mANAGER_NAME;
	}

	public String getMANAGER_TEL() {
		return MANAGER_TEL;
	}

	public void setMANAGER_TEL(String mANAGER_TEL) {
		MANAGER_TEL = mANAGER_TEL;
	}

	public String getACADEMY_EMAIL() {
		return ACADEMY_EMAIL;
	}

	public void setACADEMY_EMAIL(String aCADEMY_EMAIL) {
		ACADEMY_EMAIL = aCADEMY_EMAIL;
	}

	public String getHOMEPAGE() {
		return HOMEPAGE;
	}

	public void setHOMEPAGE(String hOMEPAGE) {
		HOMEPAGE = hOMEPAGE;
	}

	public String getACADEMY_INTRODUCE() {
		return ACADEMY_INTRODUCE;
	}

	public void setACADEMY_INTRODUCE(String aCADEMY_INTRODUCE) {
		ACADEMY_INTRODUCE = aCADEMY_INTRODUCE;
	}
}
