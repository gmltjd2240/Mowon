package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.BDto;
import com.study.spring.dto.RegDto;


import com.study.spring.dto.StudentDto;
import com.study.spring.dto.TeacherDto;


public interface TeacherDao {
	
	public void TeacherRegistration(String aCADEMY_NAME, String cLASS_NAME, String tEACHER_NAME, String tEACHER_TEL,
			String tEACHER_GENDER, String tEACHER_BIRTH, String tEACHER_EMAIL, String tEACHER_SUBJECT,
			String tEACHER_ENDSCHOOL, String tEACHER_MAJOR, String tEACHER_INTRODUCE, String tEACHER_CAREER,String TEACHER_PW);
	
	//강사정보수정
	public void TeacherInfoModify(String aCADEMY_NAME, String tEACHER_NAME, String tEACHER_TEL,
			String tEACHER_GENDER, String tEACHER_EMAIL, String tEACHER_SUBJECT,
			String tEACHER_ENDSCHOOL, String tEACHER_MAJOR, String tEACHER_INTRODUCE, String tEACHER_CAREER,String TEACHER_PW);
	
	//강사 반이름 넣기
	public void TeacherClass(String aCADEMY_NAME, String cLASS_NAME, String tEACHER_NAME);
	//강사 수업 삭제
	public void TeacherClassDelete(String aCADEMY_NAME, String cLASS_NAME, String tEACHER_NAME);
	//강사 리스트
	public ArrayList<BDto> listDao(String ACADEMY_NAME,int endPage, int startPage);
	public ArrayList<BDto> TeacherNameDao(String ACADEMY_NAME);
	//강사 전화번호
	public TeacherDto searchNumberDao(String ACADMY_NAME, String CLASS_NAME);
	public ArrayList<BDto> searchlistDao(String ACADEMY_NAME, int endPage, int startPage, String search, String division);
	
	public Integer pageDao(String ACADEMY_NAME,String division,String search);
	public Integer pageDao1(String ACADEMY_NAME);
	
	//강사 정보보기
	public ArrayList<BDto> TeacherInfo(String aCADEMY_NAME,String tEACHER_NAME);

	// 안드로이드 강사 로그인 체크용
	public TeacherDto AndroidLoginCheck(String userId, String userPw);

}
