package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.AttendanceDto;
import com.study.spring.dto.BDto;
import com.study.spring.dto.StudentDto;

public interface StudentDao {
	
	// 학생 정보 조회 로그인 체크용
	public StudentDto AndroidLoginCheck(String userId, String userPw);
	
	// 학생 목록
	public ArrayList<StudentDto> AttendanceListDao(int endPage, int startPage, String CLASS_NAME);
	
	public void AttendanceModifyDao(String CLASS_NAME, String STUDENT_NAME, String STUDENT_TEL, String STUDENT_PW, String GUARDIAN_TEL);
	
	public Integer AttendancePageDao(String CLASS_NAME);
	
	
	// 학생의 현재상태 및 출결 처리시각
//	public ArrayList<AttendanceDto> AttendanceList2Dao(int endPage, int startPage, String CLASS_NAME);
	
	public Integer AttendancePageDao2(String CLASS_NAME);
	
	//학생 등록 및 리스트
	public void StudentRegistration(String aCADEMY_NAME, String cLASS_NAME, String sTUDENT_NAME, String sTUDENT_GENDER,
			String sTUDENT_TEL, String sTUDENT_PW, String sTUDENT_BIRTH, String gUARDIAN_NAME,
			String gUARDIAN_TEL, String GUARDIAN_GENDER,String STUDENT_STATE);
	
	public Integer pageDao(String ACADEMY_NAME,String division,String search);
	public Integer pageDao1(String ACADEMY_NAME);
	public Integer pageDao2(String ACADEMY_NAME,String CLASS_NAME);
	public Integer pageDao3(String ACADEMY_NAME,String STUDENT_STATE);
	public Integer pageDao4(String ACADEMY_NAME,String STUDENT_STATE,String division,String search);
	
	public ArrayList<StudentDto> StateList(String ACADEMY_NAME,String STUDENT_STATE,int endPage, int startPage);
	public ArrayList<StudentDto> searchStateList(String ACADEMY_NAME,String STUDENT_STATE,int endPage, int startPage,String division,String search);
	
	
	public ArrayList<StudentDto> listDao(String ACADEMY_NAME,int endPage, int startPage);
	public ArrayList<StudentDto> ClasslistDao(String ACADEMY_NAME,String CLASS_NAME,int endPage, int startPage);
	public ArrayList<StudentDto> ClassStudentDao(String ACADEMY_NAME,String CLASS_NAME);
	public ArrayList<StudentDto> StudentNameDao(String ACADEMY_NAME);
	
	public ArrayList<StudentDto> StudentInfo(String aCADEMY_NAME,String STUDENT_NAME,String STUDENT_TEL);
	public ArrayList<StudentDto> StudentInfo1(String aCADEMY_NAME,String STUDENT_TEL);
	public ArrayList<StudentDto> searchlistDao(String ACADEMY_NAME,String STUDENT_STATE, int endPage, int startPage, String search, String division);
	
	//반 삭제시 학생들 정보 업뎃
	public void ClassDelete(String aCADEMY_NAME, String cLASS_NAME, String cLASS_NAME2);
	
	//학생들 반 선택 삭제
	public void ClassStudentDelete(String aCADEMY_NAME, String cLASS_NAME, String cLASS_NAME2,String Student_name);
	
	//학생 정보 수정
	public void StudentModify(String aCADEMY_NAME,String STUDENT_NAME, String STUDENT_TEL,
			String cLASS_NAME, String sTUDENT_GENDER,
			String sTUDENT_TEL, String sTUDENT_PW, String sTUDENT_BIRTH, String gUARDIAN_NAME,
			String gUARDIAN_TEL, String GUARDIAN_GENDER,String STUDENT_STATE,String STUDENT_REASON);
	
}

