package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.RegDto;


public interface RegDao {
	
	public void RegWrite(String aCADEMY_ID, String aCADEMY_PW, String aCADEMY_NAME, String aCADEMY_TEL, String aCADEMY_ADDRESS, 
			String mANAGER_NAME, String mANAGER_TEL, String cONTRACT_PERIOD);
	public void RegOK(String aCADEMY_ID, String aCADEMY_PW, String aCADEMY_NAME, String aCADEMY_TEL, String aCADEMY_ADDRESS, 
			 String mANAGER_NAME, String mANAGER_TEL, String cONTRACT_PERIOD);
	public void YN(String REG_NUM);
	public void NY(String REG_NUM);
	public ArrayList<RegDto> listDao(int endPage, int startPage);
	public Integer pageDao();
	public RegDto viewDao(String ACADEMY_NAME);
	public Integer idcheck(String userid);
	public Integer namecheck(String acname);
}
