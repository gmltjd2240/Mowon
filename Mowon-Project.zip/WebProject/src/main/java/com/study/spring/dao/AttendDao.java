package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.AttendDto;
import com.study.spring.dto.ClassDto;
import com.study.spring.dto.StudentDto;


public interface AttendDao {
	
	// 학원 반 출퇴근 시간 가져오기
	public ClassDto classTime(String ACADEMY_NAME, String CLASS_NAME);
	
	// 출결 체크 전 확인
	public Integer attendSelect(String ACADEMY_NAME, String CLASS_NAME, String STUDENT_NAME, String ATTEND_DATE);
	
	// 출결 체크시 인서트
	public void attendInsert(String ACADEMY_NAME, String CLASS_NAME, String STUDENT_NAME, 
							 String ATTEND_DATE, String ATTEND_STAT, String checkTime);
	
	// 출석체크시 등하원 현황 업데이트
	public void studentStatus(	String ATTEND_STAT, String ATTEND_TIME,
								String ACADEMY_NAME, String CLASS_NAME, String STUDENT_NAME);
	
	// 강사용 블루투스 출석체크시 학생 목록 불러오기
	public ArrayList<StudentDto> TeacherAttendCheck(String ACADEMY_NAME, String CLASS_NAME);
	

	// 일일등하원현황 리스트
	public ArrayList<StudentDto> AttendList(int endPage, int startPage, String ACADEMY_NAME);
	
	public ArrayList<StudentDto> AttendSearchList(int endPage, int startPage, String ACADEMY_NAME, String AttendSearch, String Category);
	
	public Integer Attendpage(String ACADEMY_NAME);
	
	public Integer AttendSearchpage(String ACADEMY_NAME, String AttendSearch, String Category);
	
	public StudentDto AttendInfo(String ACADEMY_NAME, String CLASS_NAME, String StudentName);
	
	public AttendDto AttendStartTime(String ACADEMY_NAME, String CLASS_NAME, String STUDENT_NAME, String ATTEND_DATE);
	
	public AttendDto AttendEndTime(String ACADEMY_NAME, String CLASS_NAME, String STUDENT_NAME, String ATTEND_DATE);
	
	public ArrayList<AttendDto> MonthDate(String ACADEMY_NAME);
	
	// 월별현황
	public ArrayList<StudentDto> AttendMonthInfo(int endPage, int startPage, String ACADEMY_NAME);
	
	public Integer InPeople(String ACADEMY_NAME);
	
	public Integer OutPeople(String ACADEMY_NAME);
	
	
//	public void AcademyBoard_Reg(String AcademyName, String AcademyTitle, String AcademyContent, int AcademyBid);
//	
//	public AcademyBoardDto AcademyContent_viewDao(String AcademyBoardAllId);
//	
//	public void AcademyBoard_Delete(int AcademyBoardAllId);
//
//	public void AcademyBoard_modifyDao(String AcademyBoardAllId, String AcademyTitle, String AcademyContent);
//	

//	
//	public Integer AcademyContent_Bid(String AcademyName);
	
//	출결현황불러오기.
	public ArrayList<AttendDto> SubAttendCheck(String ACADEMY_NAME, String TODAY); 


}

