package com.study.spring.dto;

import java.sql.Timestamp;

public class RegDto {
	
	String REG_NUM;
	String ACADEMY_ID;
	String ACADEMY_PW;
	String ACADEMY_NAME;
	String ACADEMY_TEL;
	String ACADEMY_ADDRESS;
	Timestamp REG_DATE;
	String MANAGER_NAME;
	String MANAGER_TEL;
	String CONTRACT_PERIOD;
	String CONFIRM_YN;
	
	// 학원정보 확인 및 수정 시 들고올 추가 데이터 E-MAIL, 홈페이지
	String ACADEMY_EMAIL;
	String HOMEPAGE;

	public RegDto() {
	}
			
	public RegDto(String REG_NUM,String aCADEMY_ID, String aCADEMY_PW, String aCADEMY_NAME, String aCADEMY_TEL, String aCADEMY_ADDRESS,
			Timestamp rEG_DATE, String mANAGER_NAME, String mANAGER_TEL, String cONTRACT_PERIOD, String CONFIRM_YN, String ACADEMY_EMAIL, String HOMEPAGE){
		this.REG_NUM = REG_NUM;
		this.ACADEMY_ID = aCADEMY_ID;
		this.ACADEMY_PW = aCADEMY_PW;
		this.ACADEMY_NAME = aCADEMY_NAME;
		this.ACADEMY_TEL = aCADEMY_TEL;
		this.ACADEMY_ADDRESS = aCADEMY_ADDRESS;
		this.REG_DATE = rEG_DATE;
		this.MANAGER_NAME = mANAGER_NAME;
		this.MANAGER_TEL = mANAGER_TEL;
		this.CONTRACT_PERIOD = cONTRACT_PERIOD;
		this.CONFIRM_YN = CONFIRM_YN;
		this.ACADEMY_EMAIL = ACADEMY_EMAIL;
		this.HOMEPAGE = HOMEPAGE;
		
	}

	public String getREG_NUM() {
		return REG_NUM;
	}

	public void setREG_NUM(String rEG_NUM) {
		REG_NUM = rEG_NUM;
	}

	public String getCONFIRM_YN() {
		return CONFIRM_YN;
	}

	public void setCONFIRM_YN(String cONFIRM_YN) {
		CONFIRM_YN = cONFIRM_YN;
	}

	public String getACADEMY_ID() {
		return ACADEMY_ID;
	}

	public void setACADEMY_ID(String aCADEMY_ID) {
		ACADEMY_ID = aCADEMY_ID;
	}

	public String getACADEMY_PW() {
		return ACADEMY_PW;
	}

	public void setACADEMY_PW(String aCADEMY_PW) {
		ACADEMY_PW = aCADEMY_PW;
	}

	public String getACADEMY_NAME() {
		return ACADEMY_NAME;
	}

	public void setACADEMY_NAME(String aCADEMY_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
	}

	public String getACADEMY_TEL() {
		return ACADEMY_TEL;
	}

	public void setACADEMY_TEL(String aCADEMY_TEL) {
		ACADEMY_TEL = aCADEMY_TEL;
	}

	public String getACADEMY_ADDRESS() {
		return ACADEMY_ADDRESS;
	}

	public void setACADEMY_ADDRESS(String aCADEMY_ADDRESS) {
		ACADEMY_ADDRESS = aCADEMY_ADDRESS;
	}

	public Timestamp getREG_DATE() {
		return REG_DATE;
	}

	public void setREG_DATE(Timestamp rEG_DATE) {
		REG_DATE = rEG_DATE;
	}

	public String getMANAGER_NAME() {
		return MANAGER_NAME;
	}

	public void setMANAGER_NAME(String mANAGER_NAME) {
		MANAGER_NAME = mANAGER_NAME;
	}

	public String getMANAGER_TEL() {
		return MANAGER_TEL;
	}

	public void setMANAGER_TEL(String mANAGER_TEL) {
		MANAGER_TEL = mANAGER_TEL;
	}

	public String getCONTRACT_PERIOD() {
		return CONTRACT_PERIOD;
	}

	public void setCONTRACT_PERIOD(String cONTRACT_PERIOD) {
		CONTRACT_PERIOD = cONTRACT_PERIOD;
	}

	public String getACADEMY_EMAIL() {
		return ACADEMY_EMAIL;
	}

	public void setACADEMY_EMAIL(String aCADEMY_EMAIL) {
		ACADEMY_EMAIL = aCADEMY_EMAIL;
	}

	public String getHOMEPAGE() {
		return HOMEPAGE;
	}

	public void setHOMEPAGE(String hOMEPAGE) {
		HOMEPAGE = hOMEPAGE;
	}

}
