package com.study.spring.dto;

public class AttendDto {
	String ACADEMY_NAME;
	String CLASS_NAME;
	String STUDENT_NAME;
	String ATTEND_DATE;
	String ATTEND_STAT;
	String ATTEND_TIME;
	String EARLY_TIME;
	String OUTING_TIME;
	String VACATION_DATE;
	
	public AttendDto() {
		
	}
	
	public AttendDto(String aCADEMY_NAME, String cLASS_NAME, String sTUDENT_NAME, String aTTEND_DATE,
			String aTTEND_STAT, String aTTEND_TIME, String eARLY_TIME, String oUTING_TIME, String vACATION_DATE) {
		ACADEMY_NAME = aCADEMY_NAME;
		CLASS_NAME = cLASS_NAME;
		STUDENT_NAME = sTUDENT_NAME;
		ATTEND_DATE = aTTEND_DATE;
		ATTEND_STAT = aTTEND_STAT;
		ATTEND_TIME = aTTEND_TIME;
		EARLY_TIME = eARLY_TIME;
		OUTING_TIME = oUTING_TIME;
		VACATION_DATE = vACATION_DATE;
	}

	public String getACADEMY_NAME() {
		return ACADEMY_NAME;
	}

	public void setACADEMY_NAME(String aCADEMY_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
	}

	public String getCLASS_NAME() {
		return CLASS_NAME;
	}

	public void setCLASS_NAME(String cLASS_NAME) {
		CLASS_NAME = cLASS_NAME;
	}

	public String getSTUDENT_NAME() {
		return STUDENT_NAME;
	}

	public void setSTUDENT_NAME(String sTUDENT_NAME) {
		STUDENT_NAME = sTUDENT_NAME;
	}

	public String getATTEND_DATE() {
		return ATTEND_DATE;
	}

	public void setATTEND_DATE(String aTTEND_DATE) {
		ATTEND_DATE = aTTEND_DATE;
	}

	public String getATTEND_STAT() {
		return ATTEND_STAT;
	}

	public void setATTEND_STAT(String aTTEND_STAT) {
		ATTEND_STAT = aTTEND_STAT;
	}

	public String getATTEND_TIME() {
		return ATTEND_TIME;
	}

	public void setATTEND_TIME(String aTTEND_TIME) {
		ATTEND_TIME = aTTEND_TIME;
	}

	public String getEARLY_TIME() {
		return EARLY_TIME;
	}

	public void setEARLY_TIME(String eARLY_TIME) {
		EARLY_TIME = eARLY_TIME;
	}

	public String getOUTING_TIME() {
		return OUTING_TIME;
	}

	public void setOUTING_TIME(String oUTING_TIME) {
		OUTING_TIME = oUTING_TIME;
	}

	public String getVACATION_DATE() {
		return VACATION_DATE;
	}

	public void setVACATION_DATE(String vACATION_DATE) {
		VACATION_DATE = vACATION_DATE;
	}
	
	
	
}
