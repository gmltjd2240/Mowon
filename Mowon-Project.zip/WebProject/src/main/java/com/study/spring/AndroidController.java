package com.study.spring;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.spring.dao.AttendDao;
import com.study.spring.dao.CalenderDao;
import com.study.spring.dao.ChatDao;
import com.study.spring.dao.NotificationDao;
import com.study.spring.dao.StudentDao;
import com.study.spring.dao.TeacherDao;
import com.study.spring.dto.AttendDto;
import com.study.spring.dto.ClassDto;
import com.study.spring.dto.StudentDto;
import com.study.spring.dto.TeacherDto;

@Controller
public class AndroidController {

	@Autowired
	private SqlSession sqlSession;

	@ResponseBody
	@RequestMapping("/userData")
	public Map<String, String> androidLoginCheck(HttpServletRequest request) {

		StudentDto studentDto;
		TeacherDto teacherDto;
		Map<String, String> result = new HashMap<String, String>();

		TeacherDao teacherDao = sqlSession.getMapper(TeacherDao.class);
		StudentDao studentDao = sqlSession.getMapper(StudentDao.class);

		String userId = request.getParameter("userId");
		String userPw = request.getParameter("userPw");

		// 강사 데이터
		teacherDto = teacherDao.AndroidLoginCheck(userId, userPw);
		
		if (teacherDto != null) {
			result.put("ACADEMY_NAME", teacherDto.getACADEMY_NAME());
			result.put("CLASS_NAME", teacherDto.getCLASS_NAME());
			result.put("USER_NAME", teacherDto.getTEACHER_NAME());
			result.put("USER_GENDER", teacherDto.getTEACHER_GENDER());
			result.put("USER_TEL", teacherDto.getTEACHER_TEL());
			result.put("USER_PW", teacherDto.getTEACHER_PW());
			result.put("USER_BIRTH", teacherDto.getTEACHER_BIRTH());
			
			//강사, 학생 구분
			result.put("LOGIN_TYPE", "TEACHER");
			
			return result;
		}
		
		
		// 학생 데이터
		studentDto = studentDao.AndroidLoginCheck(userId, userPw);

		if (studentDto != null) {
			result.put("ACADEMY_NAME", studentDto.getACADEMY_NAME());
			result.put("CLASS_NAME", studentDto.getCLASS_NAME());
			result.put("USER_NAME", studentDto.getSTUDENT_NAME());
			result.put("USER_GENDER", studentDto.getSTUDENT_GENDER());
			result.put("USER_TEL", studentDto.getSTUDENT_TEL());
			result.put("USER_PW", studentDto.getSTUDENT_PW());
			result.put("USER_BIRTH", studentDto.getSTUDENT_BIRTH());
			result.put("USER_MAC", studentDto.getSTUDENT_MAC());
			result.put("GUARDIAN_NAME", studentDto.getGUARDIAN_NAME());
			result.put("GUARDIAN_TEL", studentDto.getGUARDIAN_TEL());
			
			//강사, 학생 구분
			result.put("LOGIN_TYPE", "STUDENT");
			
		}

		return result;

	}

	@ResponseBody
	@RequestMapping("/attendCheck")
	public String androidAttendCheck(HttpServletRequest request) {

		AttendDao attendDao = sqlSession.getMapper(AttendDao.class);

		String academyName = request.getParameter("ACADEMY_NAME");
		String className = request.getParameter("CLASS_NAME");
		String studentName = request.getParameter("USER_NAME");
		String attendDate = request.getParameter("ATTEND_DATE");
		String attendTime = request.getParameter("ATTEND_TIME");

		// String academyName = "소프트웨어학원";
		// String className = "JAVA41기";
		// String studentName = "조성준";
		// String attendDate = "20181113";
		// String attendTime = "01830";

		int intAttendTime = Integer.parseInt(attendTime);

		// 학원 반 출퇴근 시간, 출결 데이터 확인
		ClassDto classDto = attendDao.classTime(academyName, className);
		int startTime = Integer.parseInt(classDto.getCLASS_START());
		int endTime = Integer.parseInt(classDto.getCLASS_END());

		int attendData = attendDao.attendSelect(academyName, className, studentName, attendDate);

		System.out.println(startTime);
		System.out.println(endTime);
		System.out.println(attendTime);

		// 출결 STAT 정의
		// 출결 데이터 확인
		// 데이터 0건 출석시간 전 - 출석
		// 데이터 0건 출석시간 후 - 지각
		// 데이터 1건 이상 퇴근시간 전 - 조퇴
		// 데이터 1건 이상 퇴근시간 후 - 퇴근
		String attendStat = null;

		if (attendData == 0) {
			if (intAttendTime <= startTime) {
				attendStat = "출석";
			} else {
				attendStat = "지각";
			}
		} else if (attendData != 0) {
			// 데이터 1건 이상
			if (intAttendTime < endTime) {
				attendStat = "조퇴";
			} else {
				attendStat = "퇴근";
			}
		}

		try {
			attendDao.attendInsert(academyName, className, studentName, attendDate, attendStat, attendTime);
			attendDao.studentStatus(attendStat, attendTime, academyName, className, studentName);
		} catch (Exception e) {
			// 출석체크 실패시 리턴값
			return "attendFail";
		}

		// 출석 성공 리턴값
		return attendStat;
	}

	@ResponseBody
	// mapping 한글처리 produces="text/plain;charset=UTF-8"
	@RequestMapping(value = "/calenderCheck", produces = "text/plain;charset=UTF-8")

	public String androidCalenderCheck(HttpServletRequest request) {
		List<AttendDto> arr1 = new ArrayList<AttendDto>();
		CalenderDao calenderdao = sqlSession.getMapper(CalenderDao.class);
		// 안드로이드에서 보내오는 걸 꺼내오는 부분 map put param 부분

		String academyName = request.getParameter("ACADEMY_NAME");
		String className = request.getParameter("CLASS_NAME");
		String studentName = request.getParameter("USER_NAME");
		String attendDate = request.getParameter("ATTEND_DATE");

		// String academyName = "소프트웨어학원";
		// String className = "JAVA41기";
		// String studentName = "조성준";
		// String attendDate = "20181114";
		System.out.println(academyName);
		System.out.println(className);
		System.out.println(studentName);
		System.out.println(attendDate);

		// 학원 반 출퇴근 시간, 출결 데이터 확인
		arr1 = calenderdao.calenderTime(academyName, className, studentName, attendDate);
		String result = "";
		for (int i = 0; i < arr1.size(); i++) {

			System.out.println("STAT : " + arr1.get(i).getATTEND_STAT() + ", TIME : " + arr1.get(i).getATTEND_TIME());
			result += "STAT : " + arr1.get(i).getATTEND_STAT() + ", TIME : " + arr1.get(i).getATTEND_TIME() + " @ ";
		}

		// System.out.println(attendDto.getATTEND_STAT());
		// System.out.println(attendDto.getATTEND_TIME());
		//
		System.out.println(result + "test ");

		return result;

	}

	@ResponseBody
	// mapping 한글처리 produces="text/plain;charset=UTF-8"
	@RequestMapping(value = "/searchNumberDao", produces = "text/plain;charset=UTF-8")

	public String searchNumberDao(HttpServletRequest request) {
	
		TeacherDao teacherDao = sqlSession.getMapper(TeacherDao.class);

		String academyName = request.getParameter("ACADEMY_NAME");
		String className = request.getParameter("CLASS_NAME");

		// param 집어넣는곳 안드에서 받은 정보를 파라미터로 집어넣는부분 기억하자 시발 ;
		TeacherDto tnumber = teacherDao.searchNumberDao(academyName, className);
		System.out.println(tnumber);
		
		JSONObject obj2 = new JSONObject();


		obj2.put("TEACHER_TEL", tnumber.getTEACHER_TEL());
		

		System.out.println(obj2.toString() + "obj결과값");
		return obj2.toString();

	}
	@ResponseBody
	// mapping 한글처리 produces="text/plain;charset=UTF-8"
	@RequestMapping(value = "/notificationCheck", produces = "text/plain;charset=UTF-8")

	public String notificationCheck(HttpServletRequest request) {
	
		NotificationDao notificationDao = sqlSession.getMapper(NotificationDao.class);

		String academyName = request.getParameter("ACADEMY_NAME");
		String className = request.getParameter("CLASS_NAME");

		// param 집어넣는곳 안드에서 받은 정보를 파라미터로 집어넣는부분 기억하자 시발 ;
		ClassDto startList = notificationDao.notificationCheck(academyName, className);
		System.out.println(startList);
		
		JSONObject obj = new JSONObject();


		obj.put("CLASS_START", startList.getCLASS_START());
		obj.put("CLASS_END", startList.getCLASS_END());

		System.out.println(obj.toString() + "obj결과값");
		return obj.toString();

	}

	@ResponseBody
	@RequestMapping("/TeacherAttendCheck")
	public JSONArray TeacherAttendCheck(HttpServletRequest request) {

		AttendDao attendDao = sqlSession.getMapper(AttendDao.class);

		String academyName = request.getParameter("ACADEMY_NAME");
		String className = request.getParameter("CLASS_NAME");

		// String academyName = "소프트웨어학원";
		// String className = "JAVA41기";

		ArrayList<StudentDto> studentList = attendDao.TeacherAttendCheck(academyName, className);

		// ArrayList<dto>를 JSON배열로 만들기
		JSONObject obj = new JSONObject();
		JSONArray resultJArray = null;

		try {
			resultJArray = new JSONArray();// 배열이 필요할때
			for (int i = 0; i < studentList.size(); i++) {
				JSONObject sObject = new JSONObject();// 배열 내에 들어갈 json
				sObject.put("STUDENT_NAME", studentList.get(i).getSTUDENT_NAME());
				sObject.put("STUDENT_MAC", studentList.get(i).getSTUDENT_MAC());
				resultJArray.add(sObject);
			}

			System.out.println(resultJArray.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultJArray;

	}
	
	
	
	@ResponseBody
	@RequestMapping("/ClassStudentList")
	public JSONArray ClassStudentList(HttpServletRequest request) {
		
		ChatDao chatDao = sqlSession.getMapper(ChatDao.class);
		
		String academyName = request.getParameter("ACADEMY_NAME");
		String className = request.getParameter("CLASS_NAME");

		ArrayList<String> studentList = new ArrayList<String>();
		
		studentList = chatDao.ClassStudentList(academyName, className);
		
		JSONArray resultJArray = new JSONArray();
		
		try {
			for(int i=0; i < studentList.size(); i++) {
				resultJArray.add(studentList.get(i));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println(resultJArray);
		
		return resultJArray;
	}
	

}
