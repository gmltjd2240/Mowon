package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.BAccount;
import com.study.spring.dto.BDto;

public interface LoginDao {
	
	//로그인 관련 메소드
	public String AccountPw(String aId);
	public String AccountName(String aId);
	
	//학원정보 들어가기전 패스워트 체크
	public String AcademyPw(String AcademyName);
	
}

