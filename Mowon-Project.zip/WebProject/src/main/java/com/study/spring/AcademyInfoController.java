package com.study.spring;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.spring.dao.AcademyDao;
import com.study.spring.dao.LoginDao;
import com.study.spring.dto.AcademyDto;
import com.study.spring.dto.BPageInfo;


/**
 * Handles requests for the application home page.
 */
@Controller
public class AcademyInfoController {
	
	int listCount = 10;	
	int pageCount = 10;
	int listHoldCount = 10;	
	int pageHoldCount = 10;
	
	@Autowired
	private SqlSession sqlSession;
	
	// 학원정보 들어가기 전 모달창에서 비밀번호 체크
	@RequestMapping(value = "/AcademyAccess",  method = RequestMethod.POST)
	public @ResponseBody String AcademyAccess(HttpServletRequest request, 
		   @RequestParam String userpw){
		LoginDao dao = sqlSession.getMapper(LoginDao.class);
		
		HttpSession session = null;
		session = request.getSession();
		
		String AcademyName= (String)session.getAttribute("name");				
		
		String UserPw = userpw;
		String resultPw = dao.AcademyPw(AcademyName);
		
		System.out.println(resultPw + "  " + "132212121212121");
		
		if(!resultPw.equals(UserPw)) {
            return "{\"result\":\""+"pwcheck\"}";
         } else {
        	return "{\"result\":\""+"true\"}";
         }
	}
	
	@RequestMapping(value="/AcademyInfo" ,method = RequestMethod.POST)
	public String AcademyInfo(HttpServletRequest request,Model model, HttpSession session) {
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		
		String AcademyName = request.getParameter("name");
		System.out.println(AcademyName+"121212212121");
		AcademyDto academyDto = dao.AcademyInfo(AcademyName);
		
		model.addAttribute("ACADEMY_ID", academyDto.getACADEMY_ID());
		model.addAttribute("ACADEMY_PW", academyDto.getACADEMY_PW());
		model.addAttribute("MANAGER_NAME", academyDto.getMANAGER_NAME());
		model.addAttribute("MANAGER_TEL", academyDto.getMANAGER_TEL());
		model.addAttribute("ACADEMY_TEL", academyDto.getACADEMY_TEL());
		model.addAttribute("ACADEMY_EMAIL", academyDto.getACADEMY_EMAIL());
		model.addAttribute("HOMEPAGE", academyDto.getHOMEPAGE());
		model.addAttribute("ACADEMY_ADDRESS", academyDto.getACADEMY_ADDRESS());
		
		return "management/Academy/AcademyInfo";
	}
	
	@RequestMapping(value="/AcademyModify",method= RequestMethod.POST)
	public String AcademyModify(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		
		String ACADEMY_NAME = request.getParameter("ACADEMY_NAME");
		
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		dao.AcademyModify(request.getParameter("ACADEMY_NAME"), request.getParameter("PASSWORD"), 
				request.getParameter("MANAGER_NAME"), request.getParameter("MANAGER_TEL"), 
				request.getParameter("ACADEMY_TEL"), request.getParameter("ACADEMY_EMAIL"), request.getParameter("HOMEPAGE"),
				request.getParameter("ACADEMY_ADDRESS"), request.getParameter("ACADEMY_INTRODUCE"));

		ACADEMY_NAME = URLEncoder.encode(ACADEMY_NAME, "UTF-8");
		
		return "redirect:AcademyInfo?name="+ACADEMY_NAME;
	}
	
	// 공지사항 등록-----------------------------------------------------------------------------
	
	@RequestMapping("/AcademyBoard_Reg")
	public String AcademyBoard_Write(HttpServletRequest request, Model model) {

		return "/management/Academy/AcademyBoard_Reg";
	}
	
	@RequestMapping("/AcademyReg_Ok")

	public String AcademyBoard_Reg(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
			
		String AcademyName= request.getParameter("name");
			
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		
		int AcademyBid = dao.AcademyContent_Bid(AcademyName);
		AcademyBid++;
		
		dao.AcademyBoard_Reg(AcademyName, request.getParameter("ACADEMYBOARD_TITLE"), request.getParameter("ACADEMYBOARD_CONTENT"), AcademyBid);
		
		AcademyName = URLEncoder.encode(AcademyName, "UTF-8");
		return "redirect:AcademyBoard?name="+AcademyName;
	}
		
	// 학원 공지사항------------------------------------------------------------------------------
	@RequestMapping(value="/AcademyBoard", method= {RequestMethod.POST,RequestMethod.GET})
	public String AcademyBoard(HttpServletRequest request, Model model) {
		
		String AcademyName = request.getParameter("name");
		System.out.println(request.getParameter("name")+"123");
		
	
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
//		session.setAttribute("cpage", nPage);
		
		BPageInfo pinfo = articlePage(request, model);
	    model.addAttribute("page", pinfo);
	      
	    nPage = pinfo.getCurPage();
	    
	    int curPage = nPage;
		int nStart = (curPage - 1) * listCount + 1;
		int nEnd = (curPage - 1) * listCount + listCount;
		String search = request.getParameter("search");
		
		if(search == null || search.equals("")) {
			model.addAttribute("Academysearch", search);
			model.addAttribute("AcademyBoard_list", dao.AcademyBoardDao(nEnd, nStart, AcademyName));
		}else {
			model.addAttribute("Academysearch", search);
			model.addAttribute("AcademyBoard_search", request.getParameter("search"));
			model.addAttribute("AcademyBoard_list", dao.AcademySearchDao(nEnd, nStart, AcademyName, request.getParameter("search")));
		}
		
		return "/management/Academy/AcademyBoard";
	}
	
	@RequestMapping(value="/AcademyBoard_Content", method= {RequestMethod.POST,RequestMethod.GET})
	public String content_view(HttpServletRequest request, Model model) {

		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		
		model.addAttribute("AcademyContent_view", dao.AcademyContent_viewDao(request.getParameter("Academy_AllId")));
		
		return "/management/Academy/AcademyBoard_Content";
	}
	
	// 공지사항 수정---------------------------------------------------------------------------------
	@RequestMapping("/AcademyBoard_Modify")
	public String AcademyBoard_Modify(HttpServletRequest request, Model model) {
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		
		model.addAttribute("AcademyContent_view", dao.AcademyContent_viewDao(request.getParameter("Academy_AllId")));
		
		return "/management/Academy/AcademyBoard_Modify";
	}
	
	@RequestMapping(value="/AcademyBoard_ModifyOk",method= {RequestMethod.POST,RequestMethod.GET})
	public String AcademyBoard_ModifyOk(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		String Academy_AllId=request.getParameter("ACADEMY_ALLID");
		
		dao.AcademyBoard_modifyDao(request.getParameter("ACADEMY_ALLID"), request.getParameter("ACADEMYBOARD_TITLE"), request.getParameter("ACADEMYBOARD_CONTENT"));
		
		Academy_AllId = URLEncoder.encode(Academy_AllId, "UTF-8");

		return "redirect:AcademyBoard_Content?Academy_AllId="+Academy_AllId;
	}
	
	// 공지사항 삭제--------------------------------------------------------------------------------------------
	
	@RequestMapping(value="/AcademyBoard_Delete", method= {RequestMethod.POST,RequestMethod.GET})
	public String AcademyBoard_Delete(HttpServletRequest request,Model model, HttpSession session) throws UnsupportedEncodingException{
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		
		String ACADEMY_NAME = request.getParameter("name");
		
		int AcademyBoardAllId = Integer.parseInt(request.getParameter("Academy_AllId")); 
		System.out.println(AcademyBoardAllId+"12121212121212121");
		dao.AcademyBoard_Delete(AcademyBoardAllId);
		
		ACADEMY_NAME = URLEncoder.encode(ACADEMY_NAME, "UTF-8");
	    
		return "redirect:AcademyBoard?name="+ACADEMY_NAME;
	}

	// 학원 비콘사용여부------------------------------------------------------------------------------
   @RequestMapping(value="/AcademyBeacon", method= {RequestMethod.POST,RequestMethod.GET})
   public String AcademyBeacon(HttpServletRequest request, Model model) {
	      AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
	      
	      HttpSession session = null;
	      session = request.getSession();
	      
	      String AcademyName= (String)session.getAttribute("name");
	      
	      int nPage = 1;
	      try {
	    	  String sPage = request.getParameter("page");
	          nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
	         
	      session.setAttribute("cpage", nPage);
	      
	      BPageInfo pinfo = BeaconPage(request, model);
	      model.addAttribute("page", pinfo);
	         
	      nPage = pinfo.getCurPage();
	       
	      int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
	      String BeaconIdsearch = request.getParameter("BeaconIdsearch");
	      
	      if(BeaconIdsearch == null || BeaconIdsearch.equals("")) {
	         session.removeAttribute("BeaconIdsearch");
	         model.addAttribute("Beaconlist", dao.Beaconlist(nEnd, nStart, AcademyName));
	         return "/management/Academy/AcademyBeacon";
	      } else {
	         session.setAttribute("BeaconIdsearch", BeaconIdsearch);
	         model.addAttribute("BeaconID_search", request.getParameter("BeaconIdsearch"));
	         model.addAttribute("BeaconSearchlist", dao.BeaconSearchlist(nEnd, nStart, AcademyName, request.getParameter("BeaconIdsearch")));
	         return "/management/Academy/AcademyBeacon";
      	}
   	}
   
   // 학원 비콘 검색--------------------------------------------------------------------------------------------
	
	@RequestMapping(value="/BeaconIdsearch", method= {RequestMethod.POST,RequestMethod.GET})
	public String BeaconIdsearch(HttpServletRequest request,Model model, HttpSession session){
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		
		String AcademyName= (String)session.getAttribute("name");
		
		int nPage = 1;
	      try {
	            String sPage = request.getParameter("page");
	            nPage = Integer.parseInt(sPage);
	         } catch (Exception e) {
	            
	         }
	      BPageInfo pinfo = articlePage(request, model);
	      model.addAttribute("page", pinfo);
	      
	      nPage = pinfo.getCurPage();
	      
	      int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
	      
	      String BeaconIdsearch =  request.getParameter("BIsearch");
	      
	      model.addAttribute("BeaconIdsearch", BeaconIdsearch);
	      model.addAttribute("BeaconSearchlist", dao.AcademySearchDao(nEnd, nStart, AcademyName, request.getParameter("BIsearch")));

	      session.setAttribute("BIsearch", BeaconIdsearch);
	      
	      return AcademyBoard(request, model);
	}
	
	@RequestMapping(value="/AcademyIntro" ,method = {RequestMethod.POST, RequestMethod.GET})
	public String AcademyIntro(HttpServletRequest request,Model model, HttpSession session) {
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		
		String AcademyName = (String) session.getAttribute("name");
		System.out.println(AcademyName+"121212212121");
		AcademyDto academyDto = dao.AcademyInfo(AcademyName);
		
		model.addAttribute("MANAGER_NAME", academyDto.getMANAGER_NAME());
		model.addAttribute("MANAGER_TEL", academyDto.getMANAGER_TEL());
		model.addAttribute("ACADEMY_TEL", academyDto.getACADEMY_TEL());
		model.addAttribute("ACADEMY_EMAIL", academyDto.getACADEMY_EMAIL());
		model.addAttribute("HOMEPAGE", academyDto.getHOMEPAGE());
		model.addAttribute("ACADEMY_ADDRESS", academyDto.getACADEMY_ADDRESS());
		model.addAttribute("ACADEMY_INTRODUCE", academyDto.getACADEMY_INTRODUCE());
		
		return "management/Academy/AcademyIntro";
	}
	
	// 학원공지사항 페이징 처리
	public BPageInfo articlePage(HttpServletRequest request, Model model) {
		
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		int totalCount = 0;

		
		HttpSession session = null;
		session = request.getSession();
		
		String AcademyName= request.getParameter("name");
		System.out.println(AcademyName+ "1212121212");
		String search = "";
		search = request.getParameter("search");
		System.out.println(search+"zzzzz");
	    int curPage = 1;
	      
//		try {
//	         String sPage = request.getParameter("page");
//	         curPage = Integer.parseInt(sPage);
//	         
////	         if (session.getAttribute("cpage") != null) {
////	            curPage = (Integer) session.getAttribute("cpage");
//	         }
//	      } catch (Exception e) {
//	      }
//		
		
		if(search == null || search.equals("")) {
			totalCount = dao.pageDao(AcademyName).intValue();
			int totalPage = totalCount / listCount;
			if (totalCount % listCount > 0)
				totalPage++;
			
			int myCurPage = curPage;
			if (myCurPage > totalPage)
				myCurPage = totalPage;
			if (myCurPage < 1)
				myCurPage = 1;
			
			int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
			
			int endPage = startPage + pageCount + 1;
			if (endPage > totalPage)
				endPage = totalPage;
			
			BPageInfo pinfo = new BPageInfo();
			// set
			pinfo.setTotalCount(totalCount);
			pinfo.setListCount(listCount);
			pinfo.setTotalPage(totalPage);
			pinfo.setCurPage(myCurPage);
			pinfo.setPageCount(pageCount);
			pinfo.setStartPage(startPage);
			pinfo.setEndPage(endPage);
			
			return pinfo;
		}else {
			 totalCount = dao.SearchpageDao(AcademyName, search).intValue();
			 int totalPage = totalCount / listCount;
				if (totalCount % listCount > 0)
					totalPage++;
				
				int myCurPage = curPage;
				if (myCurPage > totalPage)
					myCurPage = totalPage;
				if (myCurPage < 1)
					myCurPage = 1;
				
				int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
				
				int endPage = startPage + pageCount + 1;
				if (endPage > totalPage)
					endPage = totalPage;
				
				BPageInfo pinfo = new BPageInfo();
				// set
				pinfo.setTotalCount(totalCount);
				pinfo.setListCount(listCount);
				pinfo.setTotalPage(totalPage);
				pinfo.setCurPage(myCurPage);
				pinfo.setPageCount(pageCount);
				pinfo.setStartPage(startPage);
				pinfo.setEndPage(endPage);
				
				return pinfo;
		}
	}
	
	// 비콘 페이징 처리
	public BPageInfo BeaconPage(HttpServletRequest request, Model model) {
		
		AcademyDao dao = sqlSession.getMapper(AcademyDao.class);
		int totalCount = 0;
		
		HttpSession session = null;
		session = request.getSession();

		String AcademyName= request.getParameter("name");
		System.out.println(AcademyName+ "1212121212");
		String BIsearch = "";
		BIsearch = request.getParameter("BIsearch");
		System.out.println(BIsearch+"zzzzz");
	    int curPage = 1;
	      
		try {
	         String sPage = request.getParameter("page");
	         curPage = Integer.parseInt(sPage);
	         
	         if (session.getAttribute("cpage") != null) {
	            curPage = (Integer) session.getAttribute("cpage");
	         }
	      } catch (Exception e) {
	      }
		
		
		if(BIsearch == null || BIsearch.equals("")) {
			totalCount = dao.Beaconpage(AcademyName).intValue();
			int totalPage = totalCount / listCount;
			if (totalCount % listCount > 0)
				totalPage++;
			
			int myCurPage = curPage;
			if (myCurPage > totalPage)
				myCurPage = totalPage;
			if (myCurPage < 1)
				myCurPage = 1;
			
			int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
			
			int endPage = startPage + pageCount + 1;
			if (endPage > totalPage)
				endPage = totalPage;
			
			BPageInfo pinfo = new BPageInfo();
			// set
			pinfo.setTotalCount(totalCount);
			pinfo.setListCount(listCount);
			pinfo.setTotalPage(totalPage);
			pinfo.setCurPage(myCurPage);
			pinfo.setPageCount(pageCount);
			pinfo.setStartPage(startPage);
			pinfo.setEndPage(endPage);
			
			return pinfo;
		}else {
			 totalCount = dao.BeaconSearchpage(AcademyName, BIsearch).intValue();
			 int totalPage = totalCount / listCount;
				if (totalCount % listCount > 0)
					totalPage++;
				
				int myCurPage = curPage;
				if (myCurPage > totalPage)
					myCurPage = totalPage;
				if (myCurPage < 1)
					myCurPage = 1;
				
				int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
				
				int endPage = startPage + pageCount + 1;
				if (endPage > totalPage)
					endPage = totalPage;
				
				BPageInfo pinfo = new BPageInfo();
				// set
				pinfo.setTotalCount(totalCount);
				pinfo.setListCount(listCount);
				pinfo.setTotalPage(totalPage);
				pinfo.setCurPage(myCurPage);
				pinfo.setPageCount(pageCount);
				pinfo.setStartPage(startPage);
				pinfo.setEndPage(endPage);
				
				return pinfo;
		}
	}
}
