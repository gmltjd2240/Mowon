package com.study.spring.dto;

import java.sql.Timestamp;

public class AcademyBoardDto {

	String ACADEMY_ALLID;
	String ACADEMY_NAME;
	String ACADEMY_TITLE;
	String ACADEMY_CONTENT;
	Timestamp REGISTRATIONDATE;
	String REGISTRATION_DATE;
	String ACADEMY_BID;

	public AcademyBoardDto() {
	}
			
	public AcademyBoardDto(String ACADEMY_ALLID, String ACADEMY_NAME, String ACADEMY_TITLE, 
							String ACADEMY_CONTENT,	Timestamp REGISTRATIONDATE, String REGISTRATION_DATE,String ACADEMY_BID) {	
	
		this.ACADEMY_ALLID = ACADEMY_ALLID;
		this.ACADEMY_NAME = ACADEMY_NAME;
		this.ACADEMY_TITLE = ACADEMY_TITLE;
		this.ACADEMY_CONTENT = ACADEMY_CONTENT;
		this.REGISTRATIONDATE = REGISTRATIONDATE;
		this.REGISTRATION_DATE = REGISTRATION_DATE;
		this.ACADEMY_BID = ACADEMY_BID;
	}

	public String getACADEMY_ALLID() {
		return ACADEMY_ALLID;
	}

	public void setACADEMY_ALLID(String aCADEMY_ALLID) {
		ACADEMY_ALLID = aCADEMY_ALLID;
	}

	public String getACADEMY_NAME() {
		return ACADEMY_NAME;
	}

	public void setACADEMY_NAME(String aCADEMY_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
	}

	public String getACADEMY_TITLE() {
		return ACADEMY_TITLE;
	}

	public void setACADEMY_TITLE(String aCADEMY_TITLE) {
		ACADEMY_TITLE = aCADEMY_TITLE;
	}

	public String getACADEMY_CONTENT() {
		return ACADEMY_CONTENT;
	}

	public void setACADEMY_CONTENT(String aCADEMY_CONTENT) {
		ACADEMY_CONTENT = aCADEMY_CONTENT;
	}

	public Timestamp getREGISTRATIONDATE() {
		return REGISTRATIONDATE;
	}

	public void setREGISTRATIONDATE(Timestamp rEGISTRATIONDATE) {
		REGISTRATIONDATE = rEGISTRATIONDATE;
	}

	public String getREGISTRATION_DATE() {
		return REGISTRATION_DATE;
	}

	public void setREGISTRATION_DATE(String rEGISTRATION_DATE) {
		REGISTRATION_DATE = rEGISTRATION_DATE;
	}

	public String getACADEMY_BID() {
		return ACADEMY_BID;
	}

	public void setACADEMY_BID(String aCADEMY_BID) {
		ACADEMY_BID = aCADEMY_BID;
	}
	
	

	
}
