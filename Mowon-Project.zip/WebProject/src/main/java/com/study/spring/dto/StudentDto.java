package com.study.spring.dto;

public class StudentDto {
	String ACADEMY_NAME;
    String CLASS_NAME;
    String STUDENT_NAME;
    String STUDENT_GENDER;
    String STUDENT_TEL;
    String STUDENT_PW;
    String STUDENT_BIRTH;
    String STUDENT_MAC;
    String GUARDIAN_NAME;
    String GUARDIAN_TEL;
    String ATTEND_STAT;
    String ATTEND_TIME;
    String GUARDIAN_GENDER;
    String STUDENT_STATE;
    String STUDENT_REASON;
    
    
    public StudentDto() {
    	
    }


	public StudentDto(String aCADEMY_NAME, String cLASS_NAME, String sTUDENT_NAME, String sTUDENT_GENDER,
			String sTUDENT_TEL, String sTUDENT_PW, String sTUDENT_BIRTH, String sTUDENT_MAC, String gUARDIAN_NAME,
			String gUARDIAN_TEL, String ATTEND_STAT,String ATTEND_TIME,String GUARDIAN_GENDER, String STUDENT_STATE,
			String STUDENT_REASON) {
		ACADEMY_NAME = aCADEMY_NAME;
		CLASS_NAME = cLASS_NAME;
		STUDENT_NAME = sTUDENT_NAME;
		STUDENT_GENDER = sTUDENT_GENDER;
		STUDENT_TEL = sTUDENT_TEL;
		STUDENT_PW = sTUDENT_PW;
		STUDENT_BIRTH = sTUDENT_BIRTH;
		STUDENT_MAC = sTUDENT_MAC;
		GUARDIAN_NAME = gUARDIAN_NAME;
		GUARDIAN_TEL = gUARDIAN_TEL;
		this.ATTEND_STAT = ATTEND_STAT;
		this.ATTEND_TIME = ATTEND_TIME;
		this.GUARDIAN_GENDER = GUARDIAN_GENDER;
		this.STUDENT_STATE = STUDENT_STATE;
		this.STUDENT_REASON = STUDENT_REASON;
	}


	public String getACADEMY_NAME() {
		return ACADEMY_NAME;
	}


	public void setACADEMY_NAME(String aCADEMY_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
	}


	public String getCLASS_NAME() {
		return CLASS_NAME;
	}


	public void setCLASS_NAME(String cLASS_NAME) {
		CLASS_NAME = cLASS_NAME;
	}


	public String getSTUDENT_NAME() {
		return STUDENT_NAME;
	}


	public void setSTUDENT_NAME(String sTUDENT_NAME) {
		STUDENT_NAME = sTUDENT_NAME;
	}


	public String getSTUDENT_GENDER() {
		return STUDENT_GENDER;
	}


	public void setSTUDENT_GENDER(String sTUDENT_GENDER) {
		STUDENT_GENDER = sTUDENT_GENDER;
	}


	public String getSTUDENT_TEL() {
		return STUDENT_TEL;
	}


	public void setSTUDENT_TEL(String sTUDENT_TEL) {
		STUDENT_TEL = sTUDENT_TEL;
	}


	public String getSTUDENT_PW() {
		return STUDENT_PW;
	}


	public void setSTUDENT_PW(String sTUDENT_PW) {
		STUDENT_PW = sTUDENT_PW;
	}


	public String getSTUDENT_BIRTH() {
		return STUDENT_BIRTH;
	}


	public void setSTUDENT_BIRTH(String sTUDENT_BIRTH) {
		STUDENT_BIRTH = sTUDENT_BIRTH;
	}


	public String getSTUDENT_MAC() {
		return STUDENT_MAC;
	}


	public void setSTUDENT_MAC(String sTUDENT_MAC) {
		STUDENT_MAC = sTUDENT_MAC;
	}


	public String getGUARDIAN_NAME() {
		return GUARDIAN_NAME;
	}


	public void setGUARDIAN_NAME(String gUARDIAN_NAME) {
		GUARDIAN_NAME = gUARDIAN_NAME;
	}


	public String getGUARDIAN_TEL() {
		return GUARDIAN_TEL;
	}


	public void setGUARDIAN_TEL(String gUARDIAN_TEL) {
		GUARDIAN_TEL = gUARDIAN_TEL;
	}


	public String getATTEND_STAT() {
		return ATTEND_STAT;
	}


	public void setATTEND_STAT(String aTTEND_STAT) {
		ATTEND_STAT = aTTEND_STAT;
	}


	public String getATTEND_TIME() {
		return ATTEND_TIME;
	}


	public void setATTEND_TIME(String aTTEND_TIME) {
		ATTEND_TIME = aTTEND_TIME;
	}


	public String getGUARDIAN_GENDER() {
		return GUARDIAN_GENDER;
	}


	public void setGUARDIAN_GENDER(String gUARDIAN_GENDER) {
		GUARDIAN_GENDER = gUARDIAN_GENDER;
	}


	public String getSTUDENT_STATE() {
		return STUDENT_STATE;
	}


	public void setSTUDENT_STATE(String sTUDENT_STATE) {
		STUDENT_STATE = sTUDENT_STATE;
	}


	public String getSTUDENT_REASON() {
		return STUDENT_REASON;
	}


	public void setSTUDENT_REASON(String sTUDENT_REASON) {
		STUDENT_REASON = sTUDENT_REASON;
	}
	
	
	

    
  
}
