package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.BDto;
import com.study.spring.dto.SMSDto;


public interface SMSDao {
	
	public void SMSPushData(String ACADEMY_NAME,String GROUP_TYPE,String RECEIVE_TYPE,String SMS_CONTENT,String GROUP_TYPE1,String GROUP_NAME);
	
	//문자 발송 리스트
	public ArrayList<SMSDto> listDao(String ACADEMY_NAME,int endPage, int startPage);
	
	
	public Integer pageDao1(String ACADEMY_NAME);
	
	
	
}
