package com.study.spring;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.spring.dao.AttendDao;
import com.study.spring.dao.BoardDao;
import com.study.spring.dao.ClassDao;
import com.study.spring.dao.LoginDao;
import com.study.spring.dao.RegDao;
import com.study.spring.dao.StudentDao;
import com.study.spring.dao.TeacherDao;
import com.study.spring.dto.AttendDto;
import com.study.spring.dto.BPageInfo;
import com.study.spring.dto.StudentDto;

@Controller
public class mainController {
	
	int listCount = 10;	
	int pageCount = 10;
	int listHoldCount = 10;	
	int pageHoldCount = 10;
	String ACADEMY_NAME = "";
	
	int attend = 0;
	int lateness = 0;
	int early  = 0;
	int absence  = 0;
	private static final Logger logger = LoggerFactory.getLogger(mainController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	   public String home(Locale locale, Model model) {
	      logger.info("Welcome home! The client locale is {}.", locale);

	      Date date = new Date();
	      DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

	      String formattedDate = dateFormat.format(date);

	      model.addAttribute("serverTime", formattedDate);

	      BoardDao dao = sqlSession.getMapper(BoardDao.class);

	      model.addAttribute("list1", dao.listDaoann("announcement"));
	      model.addAttribute("list2", dao.listDaoinq("inquires"));
	      model.addAttribute("list3", dao.listDaoqna("QnA"));

	      return "/company/main";
	   }
	
	//--기본 메인 페이지 이동 컨트롤러-------
	
	@RequestMapping("/main")
	public String main(HttpServletRequest request, Model model) {
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		
		model.addAttribute("list1", dao.listDaoann("announcement"));
		model.addAttribute("list2", dao.listDaoinq("inquires"));
		model.addAttribute("list3", dao.listDaoqna("QnA"));

		return "/company/main";
	}
	
	// 로그인 체크 컨트롤러------
	@RequestMapping(value = "/IdChecking",  method = RequestMethod.POST)
	public @ResponseBody String IdChecking(HttpServletRequest request, 
		   @RequestParam String userid,
		   @RequestParam String userpw,Model model){
		LoginDao dao = sqlSession.getMapper(LoginDao.class);
		ACADEMY_NAME = "";
		String userData = userid;
		String userData2 = userpw;

		String resultPw = dao.AccountPw(userData);
		String resultName = dao.AccountName(userData);
		
		System.out.println(resultPw + "  " + "132212121212121");
		System.out.println(resultName+": zzzzz");
		
		if(resultPw == null) {
            return "{\"result\":\""+"idcheck\"}";
         } else if(!resultPw.equals(userData2)) {
            return "{\"result\":\""+"pwcheck\"}";
         } else {
     			HttpSession session = null;
     			session = request.getSession();
     			System.out.println("11111111111111111111111111111");
     			session.setAttribute("name", resultName);    			
     			ACADEMY_NAME = resultName;
     			System.out.println(ACADEMY_NAME);
        	return "{\"result\":\""+"true\"}";
         }
	}
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request, Model model) {
		
		HttpSession session = request.getSession();
		session.invalidate();
		
		return main(request, model);
	}

	@RequestMapping("/category")
	public String category() {

		return "/company/category";
	}
	
	@RequestMapping("/companyInfo")
	public String companyInfo() {

		return "/company/About/companyInfo";
	}
	
	@RequestMapping("/location")
	public String location() {

		return "/company/About/location";
	}

	@RequestMapping("/introduction")
	public String introduction() {

		return "/company/Solution/introduction";
	}
	
	@RequestMapping("/present")
	public String present() {

		return "/company/Solution/present";
	}
	
	@RequestMapping("/productApply")
	public String productApply() {

		return "/company/Solution/productApply";
	}
	
	// 제품 신청 컨트롤러 -------------------------------	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping(value="/regist", method=RequestMethod.POST)
	public String RegWrite(HttpServletRequest request, Model model) {
		RegDao dao = sqlSession.getMapper(RegDao.class);
		
		
		dao.RegWrite(request.getParameter("ACADEMY_ID"), request.getParameter("ACADEMY_PW"), request.getParameter("ACADEMY_NAME"),request.getParameter("ACADEMY_TEL1")+"-"+request.getParameter("ACADEMY_TEL2")+"-"+request.getParameter("ACADEMY_TEL3"),
				request.getParameter("ACADEMY_ADDRESS"),request.getParameter("MANAGER_NAME"),request.getParameter("MANAGER_TEL1")+"-"+request.getParameter("MANAGER_TEL2")+"-"+request.getParameter("MANAGER_TEL3"),request.getParameter("contract"));
	
		int nPage = 1;
	      try {
	            String sPage = request.getParameter("page");
	            nPage = Integer.parseInt(sPage);
	         } catch (Exception e) {
	            
	         }
	      BPageInfo pinfo = articlePage1(request, model);
	      model.addAttribute("page", pinfo);
	      
	      nPage = pinfo.getCurPage();
	      
	       int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
	      
	      model.addAttribute("list", dao.listDao(nEnd, nStart));
	      
		return "redirect:presentcheck";
		
	}
	@ResponseBody
	@RequestMapping("/idcheck")
		public String idcheck(@RequestBody String userid,HttpSession session) {
			RegDao dao = sqlSession.getMapper(RegDao.class);
			logger.info(userid+"111111111111111");
			int result = dao.idcheck(userid);
			if(result==0) {
				session.setAttribute("idcknum", 1);
				return "{\"result\":\""+"true\"}";
			}
			else {
				session.setAttribute("idcknum", 0);
				return "{\"result\":\""+"false\"}";
			}
	}
	
	@ResponseBody
	@RequestMapping("/namecheck")
		public String namecheck(@RequestBody String acname) {
			RegDao dao = sqlSession.getMapper(RegDao.class);
			logger.info(acname+"111111111111111");
			int result = dao.namecheck(acname);
			
			if(result==0) {
				return "{\"result\":\""+"true\"}";
			}
			else {
				return "{\"result\":\""+"false\"}";
			}
	}
	
	@RequestMapping("/presentcheck")
	   public String presentcheck(HttpServletRequest request, Model model) {
	      
	      int nPage = 1;
	      try {
	            String sPage = request.getParameter("page");
	            nPage = Integer.parseInt(sPage);
	         } catch (Exception e) {
	            
	         }
	      
	      RegDao dao = sqlSession.getMapper(RegDao.class);
	      BPageInfo pinfo = articlePage1(request, model);
	      model.addAttribute("page", pinfo);
	      
	      nPage = pinfo.getCurPage();
	      
	       int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
	      
	      model.addAttribute("list", dao.listDao(nEnd, nStart));

	      return "/company/Solution/presentcheck";
	   }
	
	@RequestMapping("/approval")
	public String approval(HttpServletRequest request, Model model) {
		RegDao dao = sqlSession.getMapper(RegDao.class);
		String a = request.getParameter("ACADEMY_NAME");
		System.out.println(a+" : gsfdmgnskldjgnsdjlnfsdl");
		
		model.addAttribute("content_view", dao.viewDao(request.getParameter("ACADEMY_NAME")));
	
		
	      
		return "/company/Solution/approval";
	}
	
	@RequestMapping(value="/approvalOK",method=RequestMethod.POST)
	public String approvalOK(HttpServletRequest request, Model model) {
		RegDao dao = sqlSession.getMapper(RegDao.class);
		dao.YN(request.getParameter("REG_NUM"));
		dao.RegOK(request.getParameter("ACADEMY_ID"), request.getParameter("ACADEMY_PW"), request.getParameter("ACADEMY_NAME"),
				request.getParameter("ACADEMY_TEL"), request.getParameter("ACADEMY_ADDRESS"),
				request.getParameter("MANAGER_NAME"), request.getParameter("MANAGER_TEL"), request.getParameter("CONTRACT_PERIOD"));
		
	      
	      return "redirect:presentcheck";
	}
	@RequestMapping(value="/approvalNO",method=RequestMethod.POST)
	public String approvalNO(HttpServletRequest request, Model model) {
		RegDao dao = sqlSession.getMapper(RegDao.class);
		dao.NY(request.getParameter("REG_NUM"));

		
	      
	      return "redirect:presentcheck";
	}

	
	//게시판 컨트롤러 ---------------------------------------
	
	@RequestMapping(value="/board", method= {RequestMethod.POST,RequestMethod.GET})
	public String board(HttpServletRequest request, Model model) {
		HttpSession session = null;
		session = request.getSession();
		
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
		session.setAttribute("cpage", nPage);
		
	      
	    BoardDao dao = sqlSession.getMapper(BoardDao.class);
	    BPageInfo pinfo = articlePage(request, model);
	    model.addAttribute("page", pinfo);
			
	    nPage = pinfo.getCurPage();	      	
	    int curPage = nPage;
	    
		int nStart = (curPage - 1) * listCount + 1;
		int nEnd = (curPage - 1) * listCount + listCount;
		System.out.println(request.getParameter("page")+"aaaaa");
		System.out.println(request.getParameter("search")+"aaaaa");
		
		String bType = request.getParameter("bType");
		String search = request.getParameter("search");
		if(search == null || search.equals("")) {
			model.addAttribute("listHold", dao.listHold("announcement"));
			model.addAttribute("list", dao.listDao(nEnd, nStart, bType));
			return "/company/Board/"+bType+"/"+bType;
		}else {
			model.addAttribute("listHold", dao.listHold("announcement"));
			model.addAttribute("search1", request.getParameter("search"));
			model.addAttribute("division1", request.getParameter("division"));
			model.addAttribute("list", dao.searchlistDao(nEnd, nStart,request.getParameter("bType"),request.getParameter("division"),request.getParameter("search")));
			return "/company/Board/"+bType+"/"+bType;
		}
		
		
	}
	
	//검색
		@RequestMapping(value="/searchs", method= {RequestMethod.POST,RequestMethod.GET})
		public String searchs(HttpServletRequest request,Model model, HttpSession session){
			BoardDao dao = sqlSession.getMapper(BoardDao.class);
			
			int nPage = 1;
		      try {
		            String sPage = request.getParameter("page");
		            nPage = Integer.parseInt(sPage);
		         } catch (Exception e) {
		            
		         }
		      BPageInfo pinfo = articlePage(request, model);
		      model.addAttribute("page", pinfo);
		      
		      nPage = pinfo.getCurPage();
		      
		       int curPage = nPage;
		      int nStart = (curPage - 1) * listCount + 1;
		      int nEnd = (curPage - 1) * listCount + listCount;
		      
		      System.out.println(request.getParameter("bType")+"게시판");
		      System.out.println(request.getParameter("division")+"구분");
		      System.out.println(request.getParameter("search")+"검색명");
		      
		      String a =  request.getParameter("search");
		      String b =  request.getParameter("division");
		      
		      
		      model.addAttribute("search1", a);
		      model.addAttribute("division1", b);
		      model.addAttribute("list", dao.searchlistDao(nEnd, nStart,request.getParameter("bType"),request.getParameter("division"),request.getParameter("search")));

		      return "/company/Board/"+request.getParameter("bType")+"/"+request.getParameter("bType");
		}

	@RequestMapping("/*_write_view")
	public String write_view(HttpServletRequest request) {
		String bType = request.getParameter("bType");
		
		return "/company/Board/"+bType+"/"+bType+"_write_view";
	}
	
	@RequestMapping("/*_write")
	public String write(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		String bType = request.getParameter("bType");
		String bTypeSeq = bType.toUpperCase();
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		
		String bName = request.getParameter("bName");
		String bTitle = request.getParameter("bTitle");
		String bContent = request.getParameter("bContent");
		
		dao.writeDao(bType, bTypeSeq, bName, bTitle, bContent);
		
		request.setAttribute("bType", bType);
		bType = URLEncoder.encode(bType, "UTF-8");
	
		return "redirect:board?bType="+bType;
	}
	
	@RequestMapping(value="/content_view", method= {RequestMethod.POST,RequestMethod.GET})
	public String content_view(HttpServletRequest request, Model model) {

		String bType = request.getParameter("bType");
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		dao.upHit(request.getParameter("bAllId"));
		
		model.addAttribute("search1", request.getParameter("search"));
		model.addAttribute("division1", request.getParameter("division"));
		model.addAttribute("content_view", dao.viewDao(request.getParameter("bAllId")));
	
		
		
		return "/company/Board/"+bType+"/"+bType+"_content_view";
	}
	
	@RequestMapping("/*_modify_view")
	public String modify_view(HttpServletRequest request, Model model) {
		String bType = request.getParameter("bType");
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		model.addAttribute("modify_view", dao.viewDao(request.getParameter("bAllId")));
	
		return "/company/Board/"+bType+"/"+bType+"_modify_view";
	}
	
	@RequestMapping("/*_modify")
	public String modify(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		String bType = request.getParameter("bType");
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		dao.modifyDao(request.getParameter("bAllId"),request.getParameter("bTitle"), request.getParameter("bContent"));
	
		String bAllId = request.getParameter("bAllId");
		bType = URLEncoder.encode(bType, "UTF-8");
		bAllId = URLEncoder.encode(bAllId, "UTF-8");
		
		return "redirect:content_view?bType="+bType+"&bAllId="+bAllId;
	}
	@RequestMapping("/*_delete")
	public String delete(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		String bType = request.getParameter("bType");
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		dao.deleteDao(request.getParameter("bAllId"));
		

		bType = URLEncoder.encode(bType, "UTF-8");
		
		return "redirect:board?bType="+bType;
	}
	
	@RequestMapping("/*_reply_view")
	public String reply_view(HttpServletRequest request, Model model) {
		String bType = request.getParameter("bType");
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		model.addAttribute("reply_view", dao.viewDao(request.getParameter("bAllId")));
	
		return "/company/Board/"+bType+"/"+bType+"_reply_view";
	}	
	
	@RequestMapping("/*_reply")
	public String reply(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		String bType = request.getParameter("bType");
		String bTypeSeq = bType.toUpperCase();
		String page = request.getParameter("page");
		
		String bName = request.getParameter("bName");
		String bTitle = request.getParameter("bTitle");
		String bContent = request.getParameter("bContent");
		int bGroup = Integer.parseInt(request.getParameter("bGroup"));
		int bStep = Integer.parseInt(request.getParameter("bStep"));
		int bIndent = Integer.parseInt(request.getParameter("bIndent"));
		
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		dao.replysDao(bGroup, bStep);
		dao.replyDao(bType, bTypeSeq, bName, bTitle, bContent, bGroup, bStep, bIndent);
		
		bType = URLEncoder.encode(bType, "UTF-8");
		page = URLEncoder.encode(page, "UTF-8");
		
		return "redirect:board?bType="+bType+"&page="+page;
	}
	
	@RequestMapping("/sub")
	public String sub(HttpServletRequest request, Model model) {
		System.out.println(ACADEMY_NAME+":112121212");
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		StudentDao Sdao = sqlSession.getMapper(StudentDao.class);
		TeacherDao Tdao = sqlSession.getMapper(TeacherDao.class);
		ClassDao Cdao = sqlSession.getMapper(ClassDao.class);
		AttendDao Adao = sqlSession.getMapper(AttendDao.class);
		
		SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");

        Calendar c1 = Calendar.getInstance();

        String strToday = SDF.format(c1.getTime());
        
        System.out.println(strToday);
        
        
        ArrayList<AttendDto> STAT = Adao.SubAttendCheck(ACADEMY_NAME, strToday);
        attend = 0;
    	lateness = 0;
    	early  = 0;
    	absence  = 0;
        for(int i = 0;i<STAT.size();i++) {
        	System.out.println(STAT.get(i).getATTEND_STAT().toString());
        	if(STAT.get(i).getATTEND_STAT().toString().equals("출석")) {
        		attend++;
        	}else if(STAT.get(i).getATTEND_STAT().toString().equals("지각")) {
        		lateness++;
        	}else if(STAT.get(i).getATTEND_STAT().toString().equals("조퇴")) {
        		early++;
        	}else if(STAT.get(i).getATTEND_STAT().toString().equals("결석")) {
        		absence++;
        	}
        }
        model.addAttribute("attend", attend);
        model.addAttribute("lateness", lateness);
        model.addAttribute("early", early);
        model.addAttribute("absence", absence);
		model.addAttribute("bCount", dao.pageDao2(ACADEMY_NAME));
		model.addAttribute("sCount", Sdao.pageDao1(ACADEMY_NAME));
		model.addAttribute("tCount", Tdao.pageDao1(ACADEMY_NAME));
		model.addAttribute("cCount", Cdao.pageDao1(ACADEMY_NAME));
		model.addAttribute("aBoard", dao.MainlistHold(ACADEMY_NAME));
		
		
		model.addAttribute("name", ACADEMY_NAME);
		
		return "/management/sub";
	}
		
	public BPageInfo articlePage(HttpServletRequest request, Model model) {
			
			BoardDao dao = sqlSession.getMapper(BoardDao.class);
			int totalCount = 0;
			String bType = request.getParameter("bType");
			String search = "";
			search = request.getParameter("search");
			System.out.println(search+"zzzzz");
			String division = "";
			division = request.getParameter("division");
			System.out.println(division+"zzzzz");
			
			HttpSession session = null;
		    session = request.getSession();
		      
		    int curPage = 1;
		      
			try {
		         String sPage = request.getParameter("page");
		         curPage = Integer.parseInt(sPage);
		         
		         if (session.getAttribute("cpage") != null) {
		            curPage = (Integer) session.getAttribute("cpage");
		         }
		      } catch (Exception e) {
		      }
			
			
			if(search == null || search.equals("")) {
				totalCount = dao.pageDao1(bType).intValue();
				int totalPage = totalCount / listCount;
				if (totalCount % listCount > 0)
					totalPage++;
				
				int myCurPage = curPage;
				if (myCurPage > totalPage)
					myCurPage = totalPage;
				if (myCurPage < 1)
					myCurPage = 1;
				
				int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
				
				int endPage = startPage + pageCount + 1;
				if (endPage > totalPage)
					endPage = totalPage;
				
				BPageInfo pinfo = new BPageInfo();
				// set
				pinfo.setTotalCount(totalCount);
				pinfo.setListCount(listCount);
				pinfo.setTotalPage(totalPage);
				pinfo.setCurPage(myCurPage);
				pinfo.setPageCount(pageCount);
				pinfo.setStartPage(startPage);
				pinfo.setEndPage(endPage);
				
				return pinfo;
			}else {
				 totalCount = dao.pageDao(bType,division,search).intValue();
				 int totalPage = totalCount / listCount;
					if (totalCount % listCount > 0)
						totalPage++;
					
					int myCurPage = curPage;
					if (myCurPage > totalPage)
						myCurPage = totalPage;
					if (myCurPage < 1)
						myCurPage = 1;
					
					int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
					
					int endPage = startPage + pageCount + 1;
					if (endPage > totalPage)
						endPage = totalPage;
					
					BPageInfo pinfo = new BPageInfo();
					// set
					pinfo.setTotalCount(totalCount);
					pinfo.setListCount(listCount);
					pinfo.setTotalPage(totalPage);
					pinfo.setCurPage(myCurPage);
					pinfo.setPageCount(pageCount);
					pinfo.setStartPage(startPage);
					pinfo.setEndPage(endPage);
					
					return pinfo;
			}
			
		}
	
	public BPageInfo articlePage1(HttpServletRequest request, Model model) {
		
		RegDao dao = sqlSession.getMapper(RegDao.class);
		
		
		HttpSession session = null;
	    session = request.getSession();
	      
	    int curPage = 1;
	      
		try {
	         String sPage = request.getParameter("page");
	         curPage = Integer.parseInt(sPage);
	         
	         if (session.getAttribute("cpage") != null) {
	            curPage = (Integer) session.getAttribute("cpage");
	         }
	      } catch (Exception e) {
	      }
		
		int totalCount = dao.pageDao().intValue();
	
		int totalPage = totalCount / listCount;
		if (totalCount % listCount > 0)
			totalPage++;
		
		int myCurPage = curPage;
		if (myCurPage > totalPage)
			myCurPage = totalPage;
		if (myCurPage < 1)
			myCurPage = 1;
		
		int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
		
		int endPage = startPage + pageCount + 1;
		if (endPage > totalPage)
			endPage = totalPage;
		
		BPageInfo pinfo = new BPageInfo();
		// set
		pinfo.setTotalCount(totalCount);
		pinfo.setListCount(listCount);
		pinfo.setTotalPage(totalPage);
		pinfo.setCurPage(myCurPage);
		pinfo.setPageCount(pageCount);
		pinfo.setStartPage(startPage);
		pinfo.setEndPage(endPage);
		
		return pinfo;
	}
	

}
