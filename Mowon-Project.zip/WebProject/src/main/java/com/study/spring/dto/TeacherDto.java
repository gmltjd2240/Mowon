package com.study.spring.dto;

public class TeacherDto {
	String ACADEMY_NAME;
	String CLASS_NAME;
	String TEACHER_NAME;
	String TEACHER_TEL;
	String TEACHER_GENDER;
	String TEACHER_BIRTH;
	String TEACHER_EMAIL;
	String TEACHER_SUBJECT;
	String TEACHER_ENDSCHOOL;
	String TEACHER_MAJOR;
	String TEACHER_INTRODUCE;
	String TEACHER_CAREER;
	String TEACHER_PW;
	String TEACHER_MAC;

	public TeacherDto() {
	}
	
	

	public TeacherDto(String aCADEMY_NAME, String cLASS_NAME, String tEACHER_NAME, String tEACHER_TEL,
			String tEACHER_GENDER, String tEACHER_BIRTH, String tEACHER_EMAIL, String tEACHER_SUBJECT,
			String tEACHER_ENDSCHOOL, String tEACHER_MAJOR, String tEACHER_INTRODUCE, String tEACHER_CAREER,String tEACHER_PW, String tEACHER_MAC) {
		ACADEMY_NAME = aCADEMY_NAME;
		CLASS_NAME = cLASS_NAME;
		TEACHER_NAME = tEACHER_NAME;
		TEACHER_TEL = tEACHER_TEL;
		TEACHER_GENDER = tEACHER_GENDER;
		TEACHER_BIRTH = tEACHER_BIRTH;
		TEACHER_EMAIL = tEACHER_EMAIL;
		TEACHER_SUBJECT = tEACHER_SUBJECT;
		TEACHER_ENDSCHOOL = tEACHER_ENDSCHOOL;
		TEACHER_MAJOR = tEACHER_MAJOR;
		TEACHER_INTRODUCE = tEACHER_INTRODUCE;
		TEACHER_CAREER = tEACHER_CAREER;
		TEACHER_PW = tEACHER_PW;
		TEACHER_MAC = tEACHER_MAC;
	}



	public String getACADEMY_NAME() {
		return ACADEMY_NAME;
	}

	public void setACADEMY_NAME(String aCADEMY_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
	}

	public String getCLASS_NAME() {
		return CLASS_NAME;
	}

	public void setCLASS_NAME(String cLASS_NAME) {
		CLASS_NAME = cLASS_NAME;
	}

	public String getTEACHER_NAME() {
		return TEACHER_NAME;
	}

	public void setTEACHER_NAME(String tEACHER_NAME) {
		TEACHER_NAME = tEACHER_NAME;
	}

	public String getTEACHER_TEL() {
		return TEACHER_TEL;
	}

	public void setTEACHER_TEL(String tEACHER_TEL) {
		TEACHER_TEL = tEACHER_TEL;
	}

	public String getTEACHER_GENDER() {
		return TEACHER_GENDER;
	}

	public void setTEACHER_GENDER(String tEACHER_GENDER) {
		TEACHER_GENDER = tEACHER_GENDER;
	}

	public String getTEACHER_BIRTH() {
		return TEACHER_BIRTH;
	}

	public void setTEACHER_BIRTH(String tEACHER_BIRTH) {
		TEACHER_BIRTH = tEACHER_BIRTH;
	}

	public String getTEACHER_EMAIL() {
		return TEACHER_EMAIL;
	}

	public void setTEACHER_EMAIL(String tEACHER_EMAIL) {
		TEACHER_EMAIL = tEACHER_EMAIL;
	}

	public String getTEACHER_SUBJECT() {
		return TEACHER_SUBJECT;
	}

	public void setTEACHER_SUBJECT(String tEACHER_SUBJECT) {
		TEACHER_SUBJECT = tEACHER_SUBJECT;
	}

	public String getTEACHER_ENDSCHOOL() {
		return TEACHER_ENDSCHOOL;
	}

	public void setTEACHER_ENDSCHOOL(String tEACHER_ENDSCHOOL) {
		TEACHER_ENDSCHOOL = tEACHER_ENDSCHOOL;
	}

	public String getTEACHER_MAJOR() {
		return TEACHER_MAJOR;
	}

	public void setTEACHER_MAJOR(String tEACHER_MAJOR) {
		TEACHER_MAJOR = tEACHER_MAJOR;
	}

	public String getTEACHER_INTRODUCE() {
		return TEACHER_INTRODUCE;
	}

	public void setTEACHER_INTRODUCE(String tEACHER_INTRODUCE) {
		TEACHER_INTRODUCE = tEACHER_INTRODUCE;
	}

	public String getTEACHER_CAREER() {
		return TEACHER_CAREER;
	}

	public void setTEACHER_CAREER(String tEACHER_CAREER) {
		TEACHER_CAREER = tEACHER_CAREER;
	}



	public String getTEACHER_PW() {
		return TEACHER_PW;
	}



	public void setTEACHER_PW(String tEACHER_PW) {
		TEACHER_PW = tEACHER_PW;
	}



	public String getTEACHER_MAC() {
		return TEACHER_MAC;
	}



	public void setTEACHER_MAC(String tEACHER_MAC) {
		TEACHER_MAC = tEACHER_MAC;
	}
	
	
	

}
