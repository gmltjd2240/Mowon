package com.study.spring;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.study.spring.dao.StudentDao;
import com.study.spring.dao.TeacherDao;
import com.study.spring.dto.BPageInfo;

@Controller
public class StudentController {

	int listCount = 10;	
	int pageCount = 10;
	String State = "";
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping(value="/StudentRegistration",method = {RequestMethod.POST,RequestMethod.GET})
	public String StudentRegistration(HttpServletRequest request, Model model) {
		
		TeacherDao dao = sqlSession.getMapper(TeacherDao.class);
		String ACADEMY_NAME = request.getParameter("name");
		
		model.addAttribute("Cname", dao.TeacherNameDao(ACADEMY_NAME));
		
		

		return "/management/Student/StudentRegistration";
	}
	
	@RequestMapping(value="/StudentList",method = {RequestMethod.POST,RequestMethod.GET})
	public String StudentList(HttpServletRequest request, Model model) {
		String ACADEMY_NAME = request.getParameter("name");
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		String search = request.getParameter("search");
		String TYPE = request.getParameter("Type");
		HttpSession session = null;
		session = request.getSession();
		
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
		session.setAttribute("cpage", nPage);
		
		BPageInfo pinfo = articlePage1(request, model);
	    model.addAttribute("page", pinfo);
	      
	    nPage = pinfo.getCurPage();
	      
	      int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
	      if(search == null || search.equals("")) {
	    	  model.addAttribute("Type1", TYPE);
	    	  model.addAttribute("list", dao.StateList(ACADEMY_NAME,TYPE,nEnd, nStart));
	    	  return "/management/Student/StudentList";
	      }else {
	    	  model.addAttribute("search1", request.getParameter("search"));
	    	  model.addAttribute("Type1", TYPE);
	    	  model.addAttribute("division1", request.getParameter("division"));
	    	  model.addAttribute("list", dao.searchStateList(ACADEMY_NAME,TYPE,nEnd, nStart, request.getParameter("division"),request.getParameter("search")));
	    	  return "/management/Student/StudentList";
	      }
	}
	
	@RequestMapping(value="/studentSubmit",method= RequestMethod.POST)
	public String teacherSubmit(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		String ACADEMY_NAME = request.getParameter("name");
		String TYPE = "재원";
		
		dao.StudentRegistration(request.getParameter("ACADEMY_NAME"), request.getParameter("CLASS_NAME"), request.getParameter("STUDENT_NAME"),
				request.getParameter("STUDENT_GENDER"), request.getParameter("STUDENT_TEL")+request.getParameter("STUDENT_PW"), request.getParameter("STUDENT_PW"),
				request.getParameter("STUDENT_BIRTH"), request.getParameter("GUARDIAN_NAME"), 
				request.getParameter("GUARDIAN_TEL")+request.getParameter("GUARDIAN_TEL1"), request.getParameter("GUARDIAN_GENDER"),"재원");

	      
	      ACADEMY_NAME = URLEncoder.encode(ACADEMY_NAME, "UTF-8");
	      TYPE = URLEncoder.encode(TYPE, "UTF-8");

		return "redirect:StudentList?name="+ACADEMY_NAME+"&Type="+TYPE;
	}
	//학생정보보기
	@RequestMapping(value="/StudentDetail", method= {RequestMethod.POST,RequestMethod.GET})
	public String StudentDetail(HttpServletRequest request,Model model, HttpSession session){
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		
		String STUDENT_NAME = request.getParameter("STUDENT_NAME");
		String ACADEMY_NAME = request.getParameter("name");
		String STUDENT_TEL = request.getParameter("STUDENT_TEL");
		
		System.out.println(STUDENT_NAME+":"+ACADEMY_NAME+":"+STUDENT_TEL);
		
		model.addAttribute("list", dao.StudentInfo(ACADEMY_NAME, STUDENT_NAME, STUDENT_TEL));

		
	     return "/management/Student/StudentDetail";
	}
	//학생정보수정
	@RequestMapping(value="/StudentModify", method= {RequestMethod.POST,RequestMethod.GET})
	public String StudentModify(HttpServletRequest request,Model model, HttpSession session){
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		
		String STUDENT_NAME = request.getParameter("STUDENT_NAME");
		String ACADEMY_NAME = request.getParameter("name");
		String STUDENT_TEL = request.getParameter("STUDENT_TEL");
		
		System.out.println(STUDENT_NAME+":"+ACADEMY_NAME+":"+STUDENT_TEL);
		TeacherDao Cdao = sqlSession.getMapper(TeacherDao.class);
		
		model.addAttribute("Cname", Cdao.TeacherNameDao(ACADEMY_NAME));
		model.addAttribute("list", dao.StudentInfo(ACADEMY_NAME, STUDENT_NAME, STUDENT_TEL));

		
	     return "/management/Student/StudentModify";
	}
	@RequestMapping(value="/StudentModifySubmit", method= {RequestMethod.POST,RequestMethod.GET})
	public String StudentModifySubmit(HttpServletRequest request,Model model, HttpSession session){
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		
		String STUDENT_NAME = request.getParameter("STUDENT_NAME");
		String ACADEMY_NAME = request.getParameter("name");
		String STUDENT_TEL = request.getParameter("sTel");

		dao.StudentModify(ACADEMY_NAME, STUDENT_NAME, STUDENT_TEL,
				request.getParameter("CLASS_NAME"),
				request.getParameter("STUDENT_GENDER"), request.getParameter("STUDENT_TEL")+request.getParameter("STUDENT_PW"), request.getParameter("STUDENT_PW"),
				request.getParameter("STUDENT_BIRTH"), request.getParameter("GUARDIAN_NAME"), 
				request.getParameter("GUARDIAN_TEL"), request.getParameter("GUARDIAN_GENDER"),
				request.getParameter("STUDENT_STATE"),request.getParameter("STUDENT_REASON"));
		
		model.addAttribute("list", dao.StudentInfo(ACADEMY_NAME, STUDENT_NAME, STUDENT_TEL));

		
		return "/management/Student/StudentDetail";
	}
	//휴원생 및 퇴원 수료생
	@RequestMapping(value="/StudentStateList",method = {RequestMethod.POST,RequestMethod.GET})
	public String StudentStateList(HttpServletRequest request, Model model) {
		String ACADEMY_NAME = request.getParameter("name");
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		String search = request.getParameter("search");
		String TYPE = request.getParameter("Type");
		HttpSession session = null;
		session = request.getSession();
		
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
		session.setAttribute("cpage", nPage);
		
		BPageInfo pinfo = articlePage1(request, model);
	    model.addAttribute("page", pinfo);
	      
	    nPage = pinfo.getCurPage();
	      
	      int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
	      if(search == null || search.equals("")) {
	    	  if(TYPE.equals("휴원")) {
	    		  State = "StudentStateList";
	    	  }else if(TYPE.equals("퇴원")) {
	    		  State = "StudentStateList2";
	    	  }else if(TYPE.equals("수료")) {
	    		  State = "StudentStateList3";
	    	  }
	    	  model.addAttribute("Type1", TYPE);
	    	  model.addAttribute("list", dao.StateList(ACADEMY_NAME,TYPE,nEnd, nStart));
	    	  return "/management/Student/"+State;
	      }else {
	    	  if(TYPE.equals("휴원")) {
	    		  State = "StudentStateList";
	    	  }else if(TYPE.equals("퇴원")) {
	    		  State = "StudentStateList2";
	    	  }else if(TYPE.equals("수료")) {
	    		  State = "StudentStateList3";
	    	  }
	    	  model.addAttribute("search1", request.getParameter("search"));
	    	  model.addAttribute("Type1", TYPE);
	    	  model.addAttribute("division1", request.getParameter("division"));
	    	  model.addAttribute("list", dao.searchStateList(ACADEMY_NAME,TYPE,nEnd, nStart, request.getParameter("division"),request.getParameter("search")));
	    	  
	    	  return "/management/Student/"+State;
	      }
	}
	//학생검색
	@RequestMapping(value="/Ssearchs", method= {RequestMethod.POST,RequestMethod.GET})
	public String Ssearchs(HttpServletRequest request,Model model, HttpSession session){
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		String TYPE = request.getParameter("Type");

		session = request.getSession();
		
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
		session.setAttribute("cpage", nPage);
		
		BPageInfo pinfo = articlePage(request, model);
	    model.addAttribute("page", pinfo);
	      
	    nPage = pinfo.getCurPage();
	      
	      int curPage = nPage;
	      int nStart = (curPage - 1) * listCount + 1;
	      int nEnd = (curPage - 1) * listCount + listCount;
	      
	      String search =  request.getParameter("search");
	      String division =  request.getParameter("division");
	      
	      
	      model.addAttribute("search1", search);
	      model.addAttribute("division1", division);
	      model.addAttribute("list", dao.searchlistDao(request.getParameter("name"),TYPE, nEnd, nStart,request.getParameter("division"),request.getParameter("search")));

	      return "/management/Student/StudentList";
	}
	
	public BPageInfo articlePage(HttpServletRequest request, Model model) {
		
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		int totalCount = 0;
		String ACADEMY_NAME = request.getParameter("name");
		System.out.println(ACADEMY_NAME+":::zzzzz");
		String search = "";
		search = request.getParameter("search");
		System.out.println(search+"zzzzz");
		String division = "";
		division = request.getParameter("division");
		System.out.println(division+"zzzzz");
		
		HttpSession session = null;
	    session = request.getSession();
	      
	    int curPage = 1;
	      
		try {
	         String sPage = request.getParameter("page");
	         curPage = Integer.parseInt(sPage);
	         
	         if (session.getAttribute("cpage") != null) {
	            curPage = (Integer) session.getAttribute("cpage");
	         }
	      } catch (Exception e) {
	      }
		
		
		if(search == null || search.equals("")) {
			totalCount = dao.pageDao1(ACADEMY_NAME).intValue();
			int totalPage = totalCount / listCount;
			if (totalCount % listCount > 0)
				totalPage++;
			
			int myCurPage = curPage;
			if (myCurPage > totalPage)
				myCurPage = totalPage;
			if (myCurPage < 1)
				myCurPage = 1;
			
			int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
			
			int endPage = startPage + pageCount + 1;
			if (endPage > totalPage)
				endPage = totalPage;
			
			BPageInfo pinfo = new BPageInfo();
			// set
			pinfo.setTotalCount(totalCount);
			pinfo.setListCount(listCount);
			pinfo.setTotalPage(totalPage);
			pinfo.setCurPage(myCurPage);
			pinfo.setPageCount(pageCount);
			pinfo.setStartPage(startPage);
			pinfo.setEndPage(endPage);
			
			return pinfo;
		}else {
			 totalCount = dao.pageDao(ACADEMY_NAME,division,search).intValue();
			 int totalPage = totalCount / listCount;
				if (totalCount % listCount > 0)
					totalPage++;
				
				int myCurPage = curPage;
				if (myCurPage > totalPage)
					myCurPage = totalPage;
				if (myCurPage < 1)
					myCurPage = 1;
				
				int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
				
				int endPage = startPage + pageCount + 1;
				if (endPage > totalPage)
					endPage = totalPage;
				
				BPageInfo pinfo = new BPageInfo();
				// set
				pinfo.setTotalCount(totalCount);
				pinfo.setListCount(listCount);
				pinfo.setTotalPage(totalPage);
				pinfo.setCurPage(myCurPage);
				pinfo.setPageCount(pageCount);
				pinfo.setStartPage(startPage);
				pinfo.setEndPage(endPage);
				
				return pinfo;
		}
		
	}
	public BPageInfo articlePage1(HttpServletRequest request, Model model) {
		
		StudentDao dao = sqlSession.getMapper(StudentDao.class);
		int totalCount = 0;
		String ACADEMY_NAME = request.getParameter("name");
		String search = "";
		search = request.getParameter("search");
		String division = "";
		division = request.getParameter("division");
		String TYPE = request.getParameter("Type");
		
		HttpSession session = null;
	    session = request.getSession();
	      
	    int curPage = 1;
	      
		try {
	         String sPage = request.getParameter("page");
	         curPage = Integer.parseInt(sPage);
	         
	         if (session.getAttribute("cpage") != null) {
	            curPage = (Integer) session.getAttribute("cpage");
	         }
	      } catch (Exception e) {
	      }
		
		
		if(search == null || search.equals("")) {
			totalCount = dao.pageDao3(ACADEMY_NAME,TYPE).intValue();
			int totalPage = totalCount / listCount;
			if (totalCount % listCount > 0)
				totalPage++;
			
			int myCurPage = curPage;
			if (myCurPage > totalPage)
				myCurPage = totalPage;
			if (myCurPage < 1)
				myCurPage = 1;
			
			int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
			
			int endPage = startPage + pageCount + 1;
			if (endPage > totalPage)
				endPage = totalPage;
			
			BPageInfo pinfo = new BPageInfo();
			// set
			pinfo.setTotalCount(totalCount);
			pinfo.setListCount(listCount);
			pinfo.setTotalPage(totalPage);
			pinfo.setCurPage(myCurPage);
			pinfo.setPageCount(pageCount);
			pinfo.setStartPage(startPage);
			pinfo.setEndPage(endPage);
			
			return pinfo;
		}else {
			 totalCount = dao.pageDao4(ACADEMY_NAME,TYPE,division,search).intValue();
			 int totalPage = totalCount / listCount;
				if (totalCount % listCount > 0)
					totalPage++;
				
				int myCurPage = curPage;
				if (myCurPage > totalPage)
					myCurPage = totalPage;
				if (myCurPage < 1)
					myCurPage = 1;
				
				int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
				
				int endPage = startPage + pageCount + 1;
				if (endPage > totalPage)
					endPage = totalPage;
				
				BPageInfo pinfo = new BPageInfo();
				// set
				pinfo.setTotalCount(totalCount);
				pinfo.setListCount(listCount);
				pinfo.setTotalPage(totalPage);
				pinfo.setCurPage(myCurPage);
				pinfo.setPageCount(pageCount);
				pinfo.setStartPage(startPage);
				pinfo.setEndPage(endPage);
				
				return pinfo;
		}
		
	}
}
