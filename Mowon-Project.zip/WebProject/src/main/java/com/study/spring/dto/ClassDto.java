package com.study.spring.dto;

import java.sql.Timestamp;

public class ClassDto {

   
   String ACADEMY_NAME;
   String CURRICULUM_NAME;
   String CLASS_NAME;
   String CLASS_LOCATION;
   String CLASS_START;
   String CLASS_END;
   String BEACON_ID;
   String TEACHER_NAME;
   String CURRICULUM_PEIOD;
   String CURRICULUM_MONEY;
   String CURRICULUM_INTRODUCE;
   String CLASS_DAY;
   

   public ClassDto() {
      // TODO Auto-generated constructor stub
   }


   public ClassDto(String aCADEMY_NAME, String cURRICULUM_NAME, String cLASS_NAME, String cLASS_LOCATION,
         String cLASS_START, String cLASS_END, String bEACON_ID, String tEACHER_NAME, String cURRICULUM_PEIOD,
         String cURRICULUM_MONEY, String cURRICULUM_INTRODUCE, String cLASS_DAY) {
      super();
      ACADEMY_NAME = aCADEMY_NAME;
      CURRICULUM_NAME = cURRICULUM_NAME;
      CLASS_NAME = cLASS_NAME;
      CLASS_LOCATION = cLASS_LOCATION;
      CLASS_START = cLASS_START;
      CLASS_END = cLASS_END;
      BEACON_ID = bEACON_ID;
      TEACHER_NAME = tEACHER_NAME;
      CURRICULUM_PEIOD = cURRICULUM_PEIOD;
      CURRICULUM_MONEY = cURRICULUM_MONEY;
      CURRICULUM_INTRODUCE = cURRICULUM_INTRODUCE;
      CLASS_DAY = cLASS_DAY;
   }


   public String getACADEMY_NAME() {
      return ACADEMY_NAME;
   }


   public void setACADEMY_NAME(String aCADEMY_NAME) {
      ACADEMY_NAME = aCADEMY_NAME;
   }


   public String getCURRICULUM_NAME() {
      return CURRICULUM_NAME;
   }


   public void setCURRICULUM_NAME(String cURRICULUM_NAME) {
      CURRICULUM_NAME = cURRICULUM_NAME;
   }


   public String getCLASS_NAME() {
      return CLASS_NAME;
   }


   public void setCLASS_NAME(String cLASS_NAME) {
      CLASS_NAME = cLASS_NAME;
   }


   public String getCLASS_LOCATION() {
      return CLASS_LOCATION;
   }


   public void setCLASS_LOCATION(String cLASS_LOCATION) {
      CLASS_LOCATION = cLASS_LOCATION;
   }


   public String getCLASS_START() {
      return CLASS_START;
   }


   public void setCLASS_START(String cLASS_START) {
      CLASS_START = cLASS_START;
   }


   public String getCLASS_END() {
      return CLASS_END;
   }


   public void setCLASS_END(String cLASS_END) {
      CLASS_END = cLASS_END;
   }


   public String getBEACON_ID() {
      return BEACON_ID;
   }


   public void setBEACON_ID(String bEACON_ID) {
      BEACON_ID = bEACON_ID;
   }


   public String getTEACHER_NAME() {
      return TEACHER_NAME;
   }


   public void setTEACHER_NAME(String tEACHER_NAME) {
      TEACHER_NAME = tEACHER_NAME;
   }


   public String getCURRICULUM_PEIOD() {
      return CURRICULUM_PEIOD;
   }


   public void setCURRICULUM_PEIOD(String cURRICULUM_PEIOD) {
      CURRICULUM_PEIOD = cURRICULUM_PEIOD;
   }


   public String getCURRICULUM_MONEY() {
      return CURRICULUM_MONEY;
   }


   public void setCURRICULUM_MONEY(String cURRICULUM_MONEY) {
      CURRICULUM_MONEY = cURRICULUM_MONEY;
   }


   public String getCURRICULUM_INTRODUCE() {
      return CURRICULUM_INTRODUCE;
   }


   public void setCURRICULUM_INTRODUCE(String cURRICULUM_INTRODUCE) {
      CURRICULUM_INTRODUCE = cURRICULUM_INTRODUCE;
   }


   public String getCLASS_DAY() {
      return CLASS_DAY;
   }


   public void setCLASS_DAY(String cLASS_DAY) {
      CLASS_DAY = cLASS_DAY;
   }
   
   

}
