package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.AcademyBoardDto;
import com.study.spring.dto.AcademyDto;

public interface ChatDao {
	
	//학원, 반 별 학생 이름 가져오기
	public ArrayList<String> ClassStudentList(String academyName, String className);
	
}
