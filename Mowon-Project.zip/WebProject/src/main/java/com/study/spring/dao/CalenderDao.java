package com.study.spring.dao;
import java.util.ArrayList;

import com.study.spring.dto.BAccount;
import com.study.spring.dto.BDto;
import com.study.spring.dto.AttendDto;

public interface CalenderDao {
	// 학원이름, 반이름, 학생이름 가져오기
	public ArrayList<AttendDto> calenderTime(String ACADEMY_NAME, String CLASS_NAME, String STUDENT_NAME, String ATTEND_DATE);



}
