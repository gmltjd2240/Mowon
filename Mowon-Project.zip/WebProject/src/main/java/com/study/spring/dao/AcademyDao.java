package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.AcademyBoardDto;
import com.study.spring.dto.AcademyDto;
import com.study.spring.dto.ClassDto;


public interface AcademyDao {
	
	// 학원정보받아오기
	public AcademyDto AcademyInfo(String AcademyName);	
	
	public void AcademyModify(String AcademyName, String AcademyPw, String ManagerName,
			String ManagerTel, String AcademyTel, String AcademyEmail, String Homepage,
			String AcademyAddress, String AcademyIntroduce);
	
	// 학원공지사항게시판
	public ArrayList<AcademyBoardDto> AcademyBoardDao(int endPage, int startPage, String AcademyName);
	
	public ArrayList<AcademyBoardDto> AcademySearchDao(int endPage, int startPage, String AcademyName, String AcademySearch);
	
	public void AcademyBoard_Reg(String AcademyName, String AcademyTitle, String AcademyContent, int AcademyBid);
	
	public AcademyBoardDto AcademyContent_viewDao(String AcademyBoardAllId);
	
	public void AcademyBoard_Delete(int AcademyBoardAllId);

	public void AcademyBoard_modifyDao(String AcademyBoardAllId, String AcademyTitle, String AcademyContent);
	
	public Integer pageDao(String AcademyName);
	
	public Integer SearchpageDao(String AcademyName, String AcademySearch);
	
	public Integer AcademyContent_Bid(String AcademyName);
	
	// 학원 비콘 사용여부
	public ArrayList<ClassDto> Beaconlist(int endPage, int startPage, String AcademyName);
	   
	public ArrayList<ClassDto> BeaconSearchlist(int endPage, int startPage, String AcademyName, String BeaconIdSearch);
	
	public Integer Beaconpage(String AcademyName);
	
	public Integer BeaconSearchpage(String AcademyName, String BeaconSearch);
	
}
