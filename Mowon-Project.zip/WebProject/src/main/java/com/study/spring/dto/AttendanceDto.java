package com.study.spring.dto;

public class AttendanceDto {
	String ACADEMY_NAME;
    String CLASS_NAME;
    String STUDENT_NAME;
    String ATTEND_DATE;
    String ATTEND_STAT;
    String IN_TIME;
    String OUT_TIME;
    String VACATION_START;
    String VACATION_END;
    
    
    public AttendanceDto() {
    	
    }

    
	public AttendanceDto(String aCADEMY_NAME, String cLASS_NAME, String sTUDENT_NAME, String aTTEND_DATE,
			String aTTEND_STAT, String iN_TIME, String oUT_TIME, String vACATION_START, String vACATION_END) {
		ACADEMY_NAME = aCADEMY_NAME;
		CLASS_NAME = cLASS_NAME;
		STUDENT_NAME = sTUDENT_NAME;
		ATTEND_DATE = aTTEND_DATE;
		ATTEND_STAT = aTTEND_STAT;
		IN_TIME = iN_TIME;
		OUT_TIME = oUT_TIME;
		VACATION_START = vACATION_START;
		VACATION_END = vACATION_END;
	}


	public String getACADEMY_NAME() {
		return ACADEMY_NAME;
	}


	public void setACADEMY_NAME(String aCADEMY_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
	}


	public String getCLASS_NAME() {
		return CLASS_NAME;
	}


	public void setCLASS_NAME(String cLASS_NAME) {
		CLASS_NAME = cLASS_NAME;
	}


	public String getSTUDENT_NAME() {
		return STUDENT_NAME;
	}


	public void setSTUDENT_NAME(String sTUDENT_NAME) {
		STUDENT_NAME = sTUDENT_NAME;
	}


	public String getATTEND_DATE() {
		return ATTEND_DATE;
	}


	public void setATTEND_DATE(String aTTEND_DATE) {
		ATTEND_DATE = aTTEND_DATE;
	}


	public String getATTEND_STAT() {
		return ATTEND_STAT;
	}


	public void setATTEND_STAT(String aTTEND_STAT) {
		ATTEND_STAT = aTTEND_STAT;
	}


	public String getIN_TIME() {
		return IN_TIME;
	}


	public void setIN_TIME(String iN_TIME) {
		IN_TIME = iN_TIME;
	}


	public String getOUT_TIME() {
		return OUT_TIME;
	}


	public void setOUT_TIME(String oUT_TIME) {
		OUT_TIME = oUT_TIME;
	}


	public String getVACATION_START() {
		return VACATION_START;
	}


	public void setVACATION_START(String vACATION_START) {
		VACATION_START = vACATION_START;
	}


	public String getVACATION_END() {
		return VACATION_END;
	}


	public void setVACATION_END(String vACATION_END) {
		VACATION_END = vACATION_END;
	}    
}
