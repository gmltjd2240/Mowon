package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.BDto;
import com.study.spring.dto.ClassDto;
import com.study.spring.dto.StudentDto;

public interface NotificationDao {
	public ClassDto notificationCheck(String ACADEMY_NAME, String CLASS_NAME);

	

}
