package com.study.spring.dao;

import java.util.ArrayList;

import com.study.spring.dto.BAccount;
import com.study.spring.dto.BDto;

public interface BoardDao {

	// 게시판 관련 메소드
	public ArrayList<BDto> listDao(int endPage, int startPage, String bType);
	
	public ArrayList<BDto> listHold(String bType);

	public void writeDao(String bType, String bTypeSeq, String bName, String bTitle, String bContent);

	public BDto viewDao(String bAllId);

	public void deleteDao(String bAllId);

	public void modifyDao(String bAllId, String bTitle, String bContent);
	public void replysDao(int bGroup, int bStep);
	public void replyDao(String bType, String bTypeSeq, String bName, String bTitle, String bContent, int bGroup, int bStep, int bIndent);	

	public void upHit(String bAllId);

	public Integer pageDao(String bType,String division,String search);
	public Integer pageDao1(String bType);

	public ArrayList<BDto> listDaoann(String bType);

	public ArrayList<BDto> listDaoinq(String bType);

	public ArrayList<BDto> listDaoqna(String bType);
	
	public ArrayList<BDto> searchlistDao(int endPage, int startPage, String bType, String search, String division);
	
	//학원 공지사항
	public Integer pageDao2(String ACADEMY_NAME);
	public ArrayList<BDto> MainlistHold(String ACADEMY_NAME);
}

