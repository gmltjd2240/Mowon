package com.study.spring.dto;

import java.sql.Timestamp;

public class SMSDto {
	
	String ACADEMY_NAME;
	Timestamp PUSH_DATE;
	String GROUP_TYPE;
	String RECEIVE_TYPE;
	String SMS_CONTENT;
	String GROUP_TYPE1;
	String GROUP_NAME;

	public SMSDto() {
	}

	public SMSDto(String aCADEMY_NAME, Timestamp pUSH_DATE, String GROUP_TYPE, String rECEIVE_TYPE, String sMS_CONTENT, String GROUP_TYPE1,String GROUP_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
		PUSH_DATE = pUSH_DATE;
		this.GROUP_TYPE = GROUP_TYPE;
		RECEIVE_TYPE = rECEIVE_TYPE;
		SMS_CONTENT = sMS_CONTENT;
		this.GROUP_TYPE1 = GROUP_TYPE1;
		this.GROUP_NAME = GROUP_NAME;
	}

	public String getACADEMY_NAME() {
		return ACADEMY_NAME;
	}

	public void setACADEMY_NAME(String aCADEMY_NAME) {
		ACADEMY_NAME = aCADEMY_NAME;
	}

	public Timestamp getPUSH_DATE() {
		return PUSH_DATE;
	}

	public void setPUSH_DATE(Timestamp pUSH_DATE) {
		PUSH_DATE = pUSH_DATE;
	}

	public String getGROUP_TYPE() {
		return GROUP_TYPE;
	}

	public void setGROUP_TYPE(String GROUP_TYPE) {
		this.GROUP_TYPE = GROUP_TYPE;
	}

	public String getRECEIVE_TYPE() {
		return RECEIVE_TYPE;
	}

	public void setRECEIVE_TYPE(String rECEIVE_TYPE) {
		RECEIVE_TYPE = rECEIVE_TYPE;
	}

	public String getSMS_CONTENT() {
		return SMS_CONTENT;
	}

	public void setSMS_CONTENT(String sMS_CONTENT) {
		SMS_CONTENT = sMS_CONTENT;
	}

	public String getGROUP_TYPE1() {
		return GROUP_TYPE1;
	}

	public void setGROUP_TYPE1(String gROUP_TYPE1) {
		GROUP_TYPE1 = gROUP_TYPE1;
	}

	public String getGROUP_NAME() {
		return GROUP_NAME;
	}

	public void setGROUP_NAME(String gROUP_NAME) {
		GROUP_NAME = gROUP_NAME;
	}
	
	
	

}
