package com.study.spring;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.spring.dao.AttendDao;
import com.study.spring.dto.BPageInfo;
import com.study.spring.dto.ClassDto;


/**
 * Handles requests for the application home page.
 */
@Controller
public class AttendanceController {

	int listCount = 10; // 한 페이지당 보여줄 게시물의 갯수
	int pageCount = 10; // 하단에 보여줄 페이지 리스트의 갯수

	@Autowired
	private SqlSession sqlSession;

	// 일일출석현황	
	@RequestMapping(value="/AttendanceDay", method= {RequestMethod.POST,RequestMethod.GET})
	public String AttendanceDay(HttpServletRequest request, Model model) {
		
		HttpSession session = null;
		session = request.getSession();
		
		String AcademyName= (String)session.getAttribute("name");
		
		AttendDao dao = sqlSession.getMapper(AttendDao.class);
		
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
		session.setAttribute("cpage", nPage);
		
		BPageInfo pinfo = AttendPage(request, model);
	    model.addAttribute("page", pinfo);
	      
	    nPage = pinfo.getCurPage();
	    System.out.println(request.getParameter("Attendsearch") + " 111111111 " + request.getParameter("category"));
	    int curPage = nPage;
		int nStart = (curPage - 1) * listCount + 1;
		int nEnd = (curPage - 1) * listCount + listCount;
		String Attendsearch = request.getParameter("Attendsearch");
		String categorysearch = request.getParameter("category");
		
		
		if(Attendsearch == null || Attendsearch.equals("")) {
			session.removeAttribute("searchSession");
			session.removeAttribute("category");
			model.addAttribute("AttendList", dao.AttendList(nEnd, nStart, AcademyName));
			return "management/Attendance/AttendanceDay";
		}else {
			session.setAttribute("searchSession", Attendsearch);
			session.setAttribute("category", categorysearch);
			model.addAttribute("AttendList", dao.AttendSearchList(nEnd, nStart, AcademyName, request.getParameter("Attendsearch"), request.getParameter("category")));
			return "management/Attendance/AttendanceDay";
		}
	}
	
	@RequestMapping(value="/AttendanceManagement", method= {RequestMethod.POST, RequestMethod.GET})
	public String AttendanceManagement(HttpServletRequest request, Model model) {
		HttpSession session = null;
		session = request.getSession();
		
		String AcademyName= (String)session.getAttribute("name");
		
		String date = LocalDateTime.now().toString();
		System.out.println(date);
		int nTmp = date.indexOf("");
		String cdate = date.substring(nTmp, nTmp+10);
		System.out.println(cdate);
		
		AttendDao dao = sqlSession.getMapper(AttendDao.class);
		
		System.out.println(AcademyName);
		System.out.println(request.getParameter("Class_Name"));
		System.out.println(request.getParameter("Student_Name"));
		
//		ClassDto classDto = dao.classTime(AcademyName, request.getParameter("Class_Name"));
//		int startTime = Integer.parseInt(classDto.getCLASS_START());
//		int endTime = Integer.parseInt(classDto.getCLASS_END());
//		
//		System.out.println(startTime + "  1218721y92340274021721073210732107362");
//		System.out.println(endTime + "  1218721y92340274021721073210732107362");
		// 11월 더미데이터
		String curDate1 = "20181101";
		String curDate2 = "20181102";
		String curDate5 = "20181105";
		String curDate6 = "20181106";
		String curDate7 = "20181107";
		String curDate8 = "20181108";
		String curDate9 = "20181109";
		String curDate12 = "20181112";
		String curDate13 = "20181113";
		String curDate14 = "20181114";
		String curDate15 = "20181115";
		String curDate16 = "20181116";
		String curDate19 = "20181119";
		String curDate20 = "20181120";
		String curDate21 = "20181121";
		String curDate22 = "20181122";
		String curDate23 = "20181123";

		//curDate 디비 더미데이터 쓰는중이라 원래 시나리오대로 동작시키려면 날짜 바꿔줘야됨!!!!
		// curDate ==> cdate (cdate 오늘 날짜 뽑아놓은거임)
		
		model.addAttribute("AttendStartTime1", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate1));
		model.addAttribute("AttendEndTime1", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate1));
		model.addAttribute("AttendStartTime2", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate2));
		model.addAttribute("AttendEndTime2", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate2));
		model.addAttribute("AttendStartTime5", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate5));
		model.addAttribute("AttendEndTime5", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate5));
		model.addAttribute("AttendStartTime6", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate6));
		model.addAttribute("AttendEndTime6", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate6));
		model.addAttribute("AttendStartTime7", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate7));
		model.addAttribute("AttendEndTime7", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate7));
		model.addAttribute("AttendStartTime8", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate8));
		model.addAttribute("AttendEndTime8", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate8));
		model.addAttribute("AttendStartTime9", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate9));
		model.addAttribute("AttendEndTime9", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate9));
		model.addAttribute("AttendStartTime12", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate12));
		model.addAttribute("AttendEndTime12", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate12));
		model.addAttribute("AttendStartTime13", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate13));
		model.addAttribute("AttendEndTime13", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate13));
		model.addAttribute("AttendStartTime14", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate14));
		model.addAttribute("AttendEndTime14", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate14));
		model.addAttribute("AttendStartTime15", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate15));
		model.addAttribute("AttendEndTime15", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate15));
		model.addAttribute("AttendStartTime16", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate16));
		model.addAttribute("AttendEndTime16", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate16));
		model.addAttribute("AttendStartTime19", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate19));
		model.addAttribute("AttendEndTime19", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate19));
		model.addAttribute("AttendStartTime20", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate20));
		model.addAttribute("AttendEndTime20", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate20));
		model.addAttribute("AttendStartTime21", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate21));
		model.addAttribute("AttendEndTime21", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate21));
		model.addAttribute("AttendStartTime22", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate22));
		model.addAttribute("AttendEndTime22", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate22));
		model.addAttribute("AttendStartTime23", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate23));
		model.addAttribute("AttendEndTime23", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate23));
		
		
		System.out.println(request.getParameter("Class_Name") +"12121212121212"+ request.getParameter("Student_Name"));
		model.addAttribute("AttendInfo", dao.AttendInfo(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name")));
		model.addAttribute("today", cdate);
//		model.addAttribute("startTime", startTime);
//		model.addAttribute("endTime", endTime);
		
//		model.addAttribute("MonthDate", dao.MonthDate(AcademyName));
		
		return "management/Attendance/AttendanceManagement";
	}
	
	@RequestMapping(value="/AttendanceMonth", method= {RequestMethod.POST, RequestMethod.GET})
	public String AttendanceMonth(HttpServletRequest request, Model model) {
		HttpSession session = null;
		session = request.getSession();
		
		String AcademyName= (String)session.getAttribute("name");
		
		String date = LocalDateTime.now().toString();
		System.out.println(date + " " + "1111111111111");
		int nTmp = date.indexOf("");
		String cdate = date.substring(nTmp, nTmp+10);
		System.out.println(cdate + " " + "222222222222");
		
		AttendDao dao = sqlSession.getMapper(AttendDao.class);
		int nPage = 1;
	      try {
	         String sPage = request.getParameter("page");
	         nPage = Integer.parseInt(sPage);
	      } catch (Exception e) {}
			
		session.setAttribute("cpage", nPage);
		
		BPageInfo pinfo = MonthAttendPage(request, model);
	    model.addAttribute("page", pinfo);
	      
	    nPage = pinfo.getCurPage();
	    int curPage = nPage;
		int nStart = (curPage - 1) * listCount + 1;
		int nEnd = (curPage - 1) * listCount + listCount;
//		ClassDto classDto = dao.classTime(AcademyName, request.getParameter("Class_Name"));
//		int startTime = Integer.parseInt(classDto.getCLASS_START());
//		int endTime = Integer.parseInt(classDto.getCLASS_END());
//		
//		System.out.println(startTime + "  1218721y92340274021721073210732107362");
//		System.out.println(endTime + "  1218721y92340274021721073210732107362");
//		String curDate = "";
//		curDate = "20181114";
//		
//		System.out.println(AcademyName);
//		System.out.println(request.getParameter("Class_Name"));
//		System.out.println(request.getParameter("Student_Name"));
//		System.out.println(curDate);
//		//curDate 디비 더미데이터 쓰는중이라 원래 시나리오대로 동작시키려면 날짜 바꿔줘야됨!!!!
//		// curDate ==> cdate (cdate 오늘 날짜 뽑아놓은거임)
//		
//		model.addAttribute("AttendStartTime", dao.AttendStartTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate));
//		model.addAttribute("AttendEndTime", dao.AttendEndTime(AcademyName, request.getParameter("Class_Name"), request.getParameter("Student_Name"), curDate));
//		
//		System.out.println(request.getParameter("Class_Name") +"12121212121212"+ request.getParameter("Student_Name"));
		model.addAttribute("AttendMonthInfo", dao.AttendMonthInfo(nEnd, nStart, AcademyName));
		model.addAttribute("InPeople", dao.InPeople(AcademyName));
		model.addAttribute("OutPeople", dao.OutPeople(AcademyName));
		model.addAttribute("today", cdate);
//		model.addAttribute("startTime", startTime);
//		model.addAttribute("endTime", endTime);
		return "management/Attendance/AttendanceMonth";
	}
	
	@RequestMapping(value="/AttendDay", method= {RequestMethod.POST, RequestMethod.GET})
	public String AttendDay(HttpServletRequest request, Model model, @RequestParam String paramDate) {
		
		System.out.println(paramDate + "11111111111111");
		
		return paramDate;
	}	
	@RequestMapping("/test")
	public String test() {

		return "management/Attendance/test";
	}

	public BPageInfo AttendPage(HttpServletRequest request, Model model) {
		
		AttendDao dao = sqlSession.getMapper(AttendDao.class);
		int totalCount = 0;
		
		HttpSession session = null;
		session = request.getSession();
		
		String AcademyName= (String)session.getAttribute("name");
		System.out.println(AcademyName+ "1212121212");
		String Attendsearch = "";
		Attendsearch = request.getParameter("Attendsearch");
		System.out.println(Attendsearch+"zzzzz");
		String category = "";
		category = request.getParameter("category");
		System.out.println(category+"zzzzz");
		
	    int curPage = 1;
	      
		try {
	         String sPage = request.getParameter("page");
	         curPage = Integer.parseInt(sPage);
	         
	         if (session.getAttribute("cpage") != null) {
	            curPage = (Integer) session.getAttribute("cpage");
	         }
	      } catch (Exception e) {
	      }
		
		
		if(Attendsearch == null || Attendsearch.equals("")) {
			totalCount = dao.Attendpage(AcademyName).intValue();
			int totalPage = totalCount / listCount;
			if (totalCount % listCount > 0)
				totalPage++;
			
			int myCurPage = curPage;
			if (myCurPage > totalPage)
				myCurPage = totalPage;
			if (myCurPage < 1)
				myCurPage = 1;
			
			int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
			
			int endPage = startPage + pageCount + 1;
			if (endPage > totalPage)
				endPage = totalPage;
			
			BPageInfo pinfo = new BPageInfo();
			// set
			pinfo.setTotalCount(totalCount);
			pinfo.setListCount(listCount);
			pinfo.setTotalPage(totalPage);
			pinfo.setCurPage(myCurPage);
			pinfo.setPageCount(pageCount);
			pinfo.setStartPage(startPage);
			pinfo.setEndPage(endPage);
			
			return pinfo;
		}else {
			 totalCount = dao.AttendSearchpage(AcademyName, Attendsearch, category).intValue();
			 int totalPage = totalCount / listCount;
				if (totalCount % listCount > 0)
					totalPage++;
				
				int myCurPage = curPage;
				if (myCurPage > totalPage)
					myCurPage = totalPage;
				if (myCurPage < 1)
					myCurPage = 1;
				
				int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
				
				int endPage = startPage + pageCount + 1;
				if (endPage > totalPage)
					endPage = totalPage;
				
				BPageInfo pinfo = new BPageInfo();
				// set
				pinfo.setTotalCount(totalCount);
				pinfo.setListCount(listCount);
				pinfo.setTotalPage(totalPage);
				pinfo.setCurPage(myCurPage);
				pinfo.setPageCount(pageCount);
				pinfo.setStartPage(startPage);
				pinfo.setEndPage(endPage);
				
				return pinfo;
		}
	}
	
public BPageInfo MonthAttendPage(HttpServletRequest request, Model model) {
		
		AttendDao dao = sqlSession.getMapper(AttendDao.class);
		int totalCount = 0;
		
		HttpSession session = null;
		session = request.getSession();
		
		String AcademyName= (String)session.getAttribute("name");
		System.out.println(AcademyName+ "1212121212");
		
	    int curPage = 1;
	      
		try {
	         String sPage = request.getParameter("page");
	         curPage = Integer.parseInt(sPage);
	         
	         if (session.getAttribute("cpage") != null) {
	            curPage = (Integer) session.getAttribute("cpage");
	         }
	      } catch (Exception e) {
	      }
			totalCount = dao.Attendpage(AcademyName).intValue();
			int totalPage = totalCount / listCount;
			if (totalCount % listCount > 0)
				totalPage++;
			
			int myCurPage = curPage;
			if (myCurPage > totalPage)
				myCurPage = totalPage;
			if (myCurPage < 1)
				myCurPage = 1;
			
			int startPage = ((myCurPage - 1) / pageCount) * pageCount + 1;
			
			int endPage = startPage + pageCount + 1;
			if (endPage > totalPage)
				endPage = totalPage;
			
			BPageInfo pinfo = new BPageInfo();
			// set
			pinfo.setTotalCount(totalCount);
			pinfo.setListCount(listCount);
			pinfo.setTotalPage(totalPage);
			pinfo.setCurPage(myCurPage);
			pinfo.setPageCount(pageCount);
			pinfo.setStartPage(startPage);
			pinfo.setEndPage(endPage);
			
			return pinfo;
	}
	
}
